<script>
	var base_url = '<?php echo base_url(); ?>'; 
	var dss = '<?php echo translate('deleted_successfully'); ?>';
	var cncle = '<?php echo translate('cancelled'); ?>';
	var cnl = '<?php echo translate('cancel'); ?>';
	var req = '<?php echo translate('required'); ?>';
	var mbn = '<?php echo translate('must_be_a_number'); ?>';
	var mbe = '<?php echo translate('must_be_a_valid_email_address'); ?>';
	var sv = "<?php echo translate('save'); ?>";
	var ppus = '<?php echo translate('product_published!'); ?>';
	var pups = '<?php echo translate('product_unpublished!'); ?>';
	var pfe = '<?php echo translate('product_featured!'); ?>';
	var pufe = '<?php echo translate('product_unfeatured!'); ?>';
	var spus = '<?php echo translate('slider_published!'); ?>';
	var supus = '<?php echo translate('slider_unpublished!'); ?>';
	var papus = '<?php echo translate('page_published!'); ?>';
	var paupus = '<?php echo translate('page_unpublished!'); ?>';
	var ntsen = '<?php echo translate('notification_sound_enabled!'); ?>';
	var ntsds = '<?php echo translate('notification_sound_disabled!'); ?>';
	var glen = '<?php echo translate('google_login_enabled!'); ?>';
	var glds = '<?php echo translate('google_login_disabled!'); ?>';
	var flen = '<?php echo translate('facebook_login_enabled!'); ?>';
	var flds = '<?php echo translate('facebook_login_disabled!'); ?>';
	var pplds = '<?php echo translate('paypal_payment_disabled!'); ?>';
	var pplen = '<?php echo translate('paypal_payment_enabled!'); ?>';
	var s_e = '<?php echo translate('slider_enabled!'); ?>';
	var s_d = '<?php echo translate('slider_disabled!'); ?>';
	var c_e = '<?php echo translate('cash_payment_enabled!'); ?>';
	var c_d = '<?php echo translate('cash_payment_disabled!'); ?>';
	var enb = '<?php echo translate('enabled!'); ?>';
	var dsb = '<?php echo translate('disabled!'); ?>';
	var enb_ven = '<?php echo translate('notification_email_sent_to_vendor!'); ?> ';
	
</script>