<?php
    foreach ($blog as $row) {
?>
    <div class="container content blog-page blog-item">		
        <!--Blog Post-->        
    	<div class="blog margin-bottom-40">
            <h2><a href=""><?php echo $row['title']; ?></a></h2>
            <div class="blog-post-tags">
                <ul class="list-unstyled list-inline blog-info">
                    <li><i class="fa fa-calendar"></i><?php echo $row['date']; ?></li>
                    <li><i class="fa fa-pencil"></i><?php echo $row['author']; ?></li>
                    <li><i class="fa fa-tags"></i><?php echo $this->db->get_where('blog_category',array('blog_category_id'=>$row['blog_category']))->row()->name; ?></li>
                </ul>                    
            </div>
            <div class="blog-img">
                <img class="img-responsive" style="width:100%;" src="<?php echo $this->crud_model->file_view('blog',$row['blog_id'],'','','no','src','',''); ?>" alt="">
            </div>
            <br>
            <?php echo $row['description']; ?>
        </div>
        <!--End Blog Post-->
    </div>
<?php
    }
?>