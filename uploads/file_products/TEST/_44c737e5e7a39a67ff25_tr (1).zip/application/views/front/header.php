<body class="header-fixed">
<div class="wrapper">
    <div class="header-<?php echo $theme_color; ?> header-sticky header-fixed">
        <div class="topbar-v3">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <!-- Topbar Navigation -->
                        <ul class="left-topbar">
                            <li>
                            	<?php
									if($set_lang = $this->session->userdata('language')){} else {
										$set_lang = $this->db->get_where('general_settings',array('type'=>'language'))->row()->value;
									}
								?>
                                <a>Language (<?php echo $set_lang; ?>)</a>
                                <ul class="language">
                                	<?php
                                    	$fields = $this->db->list_fields('language');
										foreach ($fields as $field)
										{
											if($field !== 'word' && $field !== 'word_id'){
									?>
                                    	<li <?php if($set_lang == $field){ ?>class="active"<?php } ?> >
                                        	<a href="<?php echo base_url(); ?>index.php/home/set_language/<?php echo $field; ?>">
												<?php echo $field; ?> 
												<?php if($set_lang == $field){ ?>
                                                	<i class="fa fa-check"></i>
												<?php } ?>
                                            </a>
                                        </li>
                                    <?php
											}
										}
									?>
                                </ul>
                            </li>   
                        </ul><!--/end left-topbar-->
                    </div>
                    <div class="col-sm-6">
                        <ul class="list-inline right-topbar pull-right" id="loginsets">
                        </ul>
                    </div>
                </div>
            </div><!--/container-->
                
        </div>
        <!-- End Topbar v3 -->

        <!-- Navbar -->
        <div class="navbar navbar-default mega-menu" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only"><?php echo translate('toggle_navigation');?></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home/">
                        <img id="logo-header" src="<?php echo $this->crud_model->logo('home_top_logo'); ?>" alt="Logo" class="img-responsive" style="width:148px;">
                    </a>
                </div>
                

                <div class="collapse navbar-collapse navbar-responsive-collapse">
                    <!-- Badge -->
                    <!-- End Badge -->
                    <ul class="nav navbar-nav">
                        <!-- Home -->
                        <li>
                            <a href="<?php echo base_url(); ?>index.php/home/" class="dropdown-toggle" >
                                <?php echo translate('home'); ?>
                            </a>
                        </li>
                        <!-- End Home -->
                        
                        <!-- Home -->
                        <li class="dropdown">
                            <a href="<?php echo base_url(); ?>index.php/home/contact/" class="dropdown-toggle" >
                                <?php echo translate('contact'); ?>
                            </a>
                        </li>
                        <!-- End Home -->
                        
                        <!-- Home -->
                        <li class="dropdown">
                            <a href="<?php echo base_url(); ?>index.php/home/compare/" class="dropdown-toggle" >
                                <?php echo translate('compare'); ?> (<span id="compare_num"><?php echo $this->crud_model->compared_num(); ?></span>)
                            </a>
                        </li>
                        <!-- End Home -->

                        <!-- Home -->
                        <li class="dropdown">
                            <a href="<?php echo base_url(); ?>index.php/home/store_locator/" class="dropdown-toggle" >
                                <?php echo translate('store_locator'); ?>
                            </a>
                        </li>
                        <!-- End Home -->

						<?php
                        	$pages = $this->db->get_where('page',array('status'=>'ok'))->result_array();
							foreach($pages as $row1){
						?>
                        <!-- Home -->
                        <li class="dropdown">
                            <a href="<?php echo base_url(); ?>index.php/home/page/<?php echo $row1['parmalink']; ?>" class="dropdown-toggle" >
                                <?php echo translate($row1['page_name']); ?>
                            </a>
                        </li>
                        <!-- End Home -->
                        <?php
                        	}
						?>
                    </ul>
                </div><!--/navbar-collapse-->
            </div>    
        </div>            
        <!-- End Navbar -->
    </div>
    
    <?php
        echo form_open(base_url() . 'index.php/home/filter_it', array(
            'class' => 'sky-form',
            'method' => 'post',
            'enctype' => 'multipart/form-data',
            'id' => 'frm',
            'style' => 'border:none !important;'
        ));
    ?>
        <div class="header-v4" style="height:44px;">
            <!-- Navbar -->
            <div class="navbar navbar-default mega-menu" role="navigation">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">   
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse1">
                            <span class="full-width-menu"><?php echo translate('our_brands');?></span>
                            <span class="icon-toggle">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </span>    
                        </button>
                    </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse navbar-responsive-collapse1">
                    <div class="container">
                    	
                        <div class="row" style="margin:5px 0;">
                            	<div class="col-md-2 col-sm-6"></div>
                                <div class="col-md-3 col-sm-6">
                                    <label class="select">
                                        <select name='category' id='category' >
                                            <option value="0"><?php echo translate('choose_category');?></option>
                                            <?php
                                                $categories = $this->db->get('category')->result_array();
                                                foreach($categories as $row){
                                            ?>
                                                <option value="<?php echo $row['category_id']; ?>"><?php echo ucfirst($row['category_name']); ?></option>
                                            <?php
                                                }
                                            ?>
                                        </select>
                                        <i></i>
                                    </label>
                                </div>
                                
                                <div class="col-md-3 col-sm-6">
                                    <label class="select">
                                        <select name='brand'  id='brand'>
                                            <option value="0"><?php echo translate('choose_brand');?></option>
                                        </select>
                                        <i></i>
                                    </label>
                                </div>
                                
                                <div class="col-md-2 col-sm-6">
                                    <span class="form-control sere" style="cursor:pointer;" onclick="filter_this()" >Search</span>
                                </div>
                                <div class="col-md-2 col-sm-6"></div>
                        </div>
                        
                    </div><!--/end container-->
                </div><!--/navbar-collapse-->
            </div>            
            <!-- End Navbar -->
        </div>
        
        <!--=== End Header style1 ===-->
        <div class="parallaxBg twitter-block filter_results margin-bottom-60" style="background-position: 50% 1167px; background: #EFEFEF;display:none;">
            <div class="container content " >
                <div class="result_ed col-md-9" style="margin-top:20px;">
    
                </div>
                <div class="col-md-3 filter-by-block pull-right-md result_fl">
    
                </div>
            </div>
        </div>

    </form>
                        
    <script>
    	$('#category').on('change', function(){
    		var category = $('#category').val();
    		var list1 = $('#brand');
            var p_list = $('.result_ed');
            var f_list = $('.result_fl');
            $.ajax({
                url: '<?php echo base_url(); ?>index.php/home/others/get_brand_by_cat/'+category,
                beforeSend: function() {
                    list1.html('...');
                },
                success: function(data) {
                    list1.html(data);
                },
                error: function(e) {
                    console.log(e)
                }
            });
            $.ajax({
                url: '<?php echo base_url(); ?>index.php/home/filters/'+category,
                beforeSend: function() {
                    f_list.html('...');
                },
                success: function(data) {
                    f_list.html(data);
                    setTimeout(function(){ 
                        filter_this();
                    }, 900);                    
                },
                error: function(e) {
                    console.log(e)
                }
            });
    	});

    	$('#brand').on('change', function(){
            var category = $('#category').val();
    		var brand = $('#brand').val();
            var p_list = $('.result_ed');
            var f_list = $('.result_fl');
            filter_this();
    	});

    	function filter_this(page){
            var category = $('#category').val();
            var brand = $('#brand').val();
            var p_list = $('.result_ed');
            var f_list = $('.result_fl');
            var form  = $('#frm');
            $('.filter_results').show('slow');
            var formdata = false;
            if (window.FormData){
                formdata = new FormData(form[0]);
            }

            $.ajax({
                url: form.attr('action')+'/'+page, // form action url
                type: 'POST', // form submit method get/post
                dataType: 'html', // request type html/json/xml
                data: formdata ? formdata : form.serialize(), // serialize form data 
                cache       : false,
                contentType : false,
                processData : false,
                beforeSend: function() {
                    p_list.css('opacity','0.2');
                },
                success: function(data) {
                    p_list.css('opacity','1');
                    p_list.html(data);
                },
                error: function(e) {
                    console.log(e)
                }
            });
        }
    </script>
    <style type="text/css">
        .filter_results{
            -webkit-transition: all 2s;
            transition: all 2s;
        }
    </style>


