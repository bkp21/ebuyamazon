<?php
    foreach($product_data as $row)
    {
?>
    <!--=== Shop Product ===-->
    <div class="shop-product">
        <!-- Product Head -->
        <div class="container product_head">
        	<div class="col-md-6">
                <ul class="breadcrumb-v5">
                    <li><a href="<?php echo base_url(); ?>index.php/home/"><i class="fa fa-home"></i></a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/home/category/"><?php echo translate('products');?></a></li>
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/home/category/<?php echo $row['category']; ?>">
                            <?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?>	 
                        </a>
                    </li>
                    <li class="active">
                        <a href="<?php echo base_url(); ?>index.php/home/category/<?php echo $row['category']; ?>/<?php echo $row['sub_category']; ?>">
                            <?php echo $this->crud_model->get_type_name_by_id('sub_category',$row['sub_category'],'sub_category_name'); ?>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-6" style="padding-top:10px;">
            	<div id="share"></div>
            </div>
        </div>
        <!-- Product Head -->
        
        
        <!-- Product Body -->
        <div class="container">
            <div class="row product_body">
                <div class="col-md-4">
                    <div class="ms-showcase2-template">
                        <div id="slider" class="flexslider" style="overflow:hidden;">
                        <?php
							$thumbs = $this->crud_model->file_view('product',$row['product_id'],'','','thumb','src','multi','all');
							$mains = $this->crud_model->file_view('product',$row['product_id'],'','','no','src','multi','all');
						?>
                          <ul class="slides" >
							<?php 
                                foreach ($mains as $row1) {
                            ?>
                                <li class="zoom">
                                  <img src="<?php echo $row1; ?>" class="img-responsive zoom" />
                                </li>
                            <?php 
                                }
                             ?>
                            <!-- items mirrored twice, total of 12 -->
                          </ul>
                        </div>
                        <span id="zom" class="btn-u btn-u-xs btn-u-cust">
                        	<i class="fa fa-search-plus"></i> <?php echo translate('preview');?>
                        </span>
                        <?php
                        	if(count($mains) > 1){
						?>
                        <div id="carousel" class="flexslider" style="overflow:hidden;">
                          <ul class="slides" >
                            <?php
								$i = 0;
								foreach ($thumbs as $row1) {
							?>
								<li style="border:4px solid #fff;">
                                 <a class="fancybox-button zoomer" data-rel="fancybox-button" title="<?php echo $row['title'].' ('.($i+1).')'; ?>" href="<?php echo $mains[$i]; ?>" ></a>
								  <img src="<?php echo $row1; ?>" />
								</li>
							<?php
								$i++;
								}
							 ?>
                             
                          </ul>
                        </div>
                        <script>
                            $( "#zom" ).click(function() {
                                $('.flex-active-slide').find('a').click();
                            });
                        </script>
                        <?php
                            } else if(count($mains) == 1) {
                        ?>
                            <a class="fancybox-button zoomer fancyier" data-rel="fancybox-button" title="<?php echo $row['title']; ?>" href="<?php echo $mains[0]; ?>" ></a>
                            <script>
                                $( "#zom" ).click(function() {
                                    $('.fancyier').click();
                                });
                            </script>
                        <?php
                            }
                        ?>
                    </div>
                </div>
                <div class="col-md-5" style="border-right:1px solid #D4D4D4;">
                    <div class="shop-product-heading">
                        <h2><?php echo $row['title']; ?></h2>
                        <div class="col-md-6 shadow-wrapper">       
                    	</div>
                    </div><!--/end shop product social-->
                    <div class="stars-ratings inp_rev list-inline" style="display:none;" data-pid='<?php echo $row['product_id']; ?>'>
                        <input type="radio" class="rate_it" name="rating" data-rate="5" id="rate-5">
                        <label for="rate-5"><i class="fa fa-star"></i></label>
                        <input type="radio" class="rate_it" name="rating" data-rate="4" id="rate-4">
                        <label for="rate-4"><i class="fa fa-star"></i></label>
                        <input type="radio" class="rate_it" name="rating" data-rate="3" id="rate-3">
                        <label for="rate-3"><i class="fa fa-star"></i></label>
                        <input type="radio" class="rate_it" name="rating" data-rate="2" id="rate-2">
                        <label for="rate-2"><i class="fa fa-star"></i></label>
                        <input type="radio" class="rate_it" name="rating" data-rate="1" id="rate-1">
                        <label for="rate-1"><i class="fa fa-star"></i></label>
                    </div>
                    
                    <ul class="list-inline ratings_show product-ratings margin-bottom-10 tooltips"
                    	data-original-title="<?php echo $rating = $this->crud_model->rating($row['product_id']); ?>"	
                       		data-toggle="tooltip" data-placement="left" >
                        <?php
							$r = $rating;
							$i = 0;
							while($i<5){
								$i++;
						?>
                        <li>
                        	<i class="rating<?php if($i<=$rating){ echo '-selected'; } $r--; ?> fa fa-star<?php if($r < 1 && $r > 0){ echo '-half';} ?>"></i>
                        </li>
                        <?php
							}
						?>
                        <?php
                        	if($this->session->userdata('user_login') == "yes"){
						?>
                            <li class="product-review-list pull-right">
                                <span>
                                    <a href="#" class='rev_show'><?php echo translate('give_a_rating');?></a>
                                </span>
                            </li>
                        <?php
							}
						?>
                    </ul><!--/end shop product ratings-->
                    <script>
						$('body').on('click', '.rev_show', function(){
							$('.ratings_show li').each(function() {
                                $(this).hide('fast');
                            });
							$('.inp_rev').show('slow');
						});
					</script>
                    <div class="row margin-bottom-10">
                    <?php if($row['category'] !=''){ ?>
                        <div class="col-md-4">
                            <!-- Grey Panel -->            
                            <div class="panel panel-blue">
                                <div class="panel-heading" style="padding:20px 0px;">
                                    <center><h4 class="panel-title"><?php echo translate('category');?></h4></center>
                                    <center><span><h4 style="margin:0px !important;color:#fff;"><?php echo $this->db->get_where('category',array('category_id'=>$row['category']))->row()->category_name; ?></h4></span></center>
                                </div>
                            </div>
                            <!-- End Grey Panel -->            
                        </div>
						<?php } if($row['brand'] !='') { ?>
                        <div class="col-md-4">
                            <!-- Red Panel -->            
                            <div class="panel panel-green">
                                <div class="panel-heading" style="padding:20px 0px;">
                                    <center><h4 class="panel-title"><?php echo translate('brand');?></h4></center>
                                    <center><span><h4 style="margin:0px !important;color:#fff;"><?php echo $this->db->get_where('brand',array('brand_id'=>$row['brand']))->row()->name; ?></h4></span></center>
                                </div>
                            </div>
                        </div>
                        <?php } if($row['sale_price'] !='') { ?>
                        <div class="col-md-4">
                            <!-- Red Panel -->            
                            <div class="panel panel-sea">
                                <div class="panel-heading" style="padding:20px 0px;">
                                    <center><h4 class="panel-title"><?php echo translate('PRICE');?></h4></center>
                                    <center><span><h4 style="margin:0px !important;color:#fff;"><?php echo currency().$row['sale_price']; ?></h4></span></center>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="row margin-bottom-10">
                    <?php if($row['processor'] !='') { ?>
                        <div class="col-md-4">
                            <!-- Grey Panel -->            
                            <div class="panel panel-purple">
                                <div class="panel-heading" style="padding:20px 0px;">
                                    <center><h4 class="panel-title"><?php echo translate('processor');?></h4></center>
                                    <center><span><h4 style="margin:0px !important;color:#fff;"><?php echo $row['processor']; ?></h4></span></center>
                                </div>
                            </div>
                            <!-- End Grey Panel -->            
                        </div>
                    <?php } if($row['ram'] !='') { ?>
                        <div class="col-md-4">
                            <!-- Red Panel -->            
                            <div class="panel panel-dark" style="margin:0px !important;">
                                <div class="panel-heading" style="padding:20px 0px;">
                                    <center><h4 class="panel-title"><?php echo translate('ram');?></h4></center>
                                    <center><span><h4 style="margin:0px !important;color:#fff;"><?php echo $row['ram']; ?></h4></span></center>
                                </div>
                            </div>
                        </div>
                    <?php } if($row['storage'] !='') { ?>
                        <div class="col-md-4">
                            <!-- Red Panel -->            
                            <div class="panel panel-brown">
                                <div class="panel-heading" style="padding:20px 0px;">
                                    <center><h4 class="panel-title"><?php echo translate('storage');?></h4></center>
                                    <center><span><h4 style="margin:0px !important;color:#fff;"><?php echo $row['storage']; ?></h4></span></center>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                        <div class="col-md-12">
                            <div class="col-md-12" style="background:#F1F1F1; border:1px solid #E8E8E8; padding:5px 0px;">
                            <?php   
                                if($this->session->userdata('reseller_login') == 'yes'){
                                    if('' =='') {
                            ?>
                                <div class="col-md-4 col-sm-12">
                                    <div class="btn-u btn-u-blue btn-block btn-labeled fa fa-file-text">
                                        <?php echo translate('reseller(.pdf)');?> 
                                    </div>
                                </div>
                            <?php
                                    }
                                }
                            ?>
                                <div class="col-md-4 col-sm-12">
                                    <div class="btn-u btn-u-update btn-block btn-labeled fa fa-certificate">
                                        <?php echo translate('resellers');?>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12">
                                    <div class="btn-u btn-u-cust btn-block btn-labeled fa fa-video-camera">
                                        <?php echo translate('vedio');?>
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
                    <?php /*?><ul class="list-inline shop-product-prices">
                        <li class="shop-violet"><?php echo currency().$row['sale_price']; ?></li>
                    </ul><!--/end shop product prices-->
                    
                    <div class="margin-bottom-40">
                        
                        <?php 
                            $wish = $this->crud_model->is_wished($row['product_id']); 
                        ?>
                        <button type="button" data-pid='<?php echo $row['product_id']; ?>' 
                            class="btn-u btn-brd btn-brd-hover rounded btn-u-pink btn-u-xs <?php if($wish == 'yes'){ ?>btn_wished<?php } else {?>btn_wish<?php } ?>">
                            <i class="fa fa-heart"></i>
                            <?php if($wish == 'yes'){ ?>
                                <?php echo translate('added_to_wishlist');?>
                            <?php } else {?>
                                <?php echo translate('add_to_wishlist');?>
                            <?php } ?>
                        </button>
                        
                    </div><?php */?>
                    <!--/end product quantity--> 
                    </form>
                    
                </div>
                <div id="pnopoi"></div>
                <div class="col-md-3">
                    <!-- Related Products -->
                    <div class="sdbar posts margin-bottom-20">
                        <h4 class="text_color center_text mr_top_0"><?php echo translate('similar_products'); ?></h4>
                        <?php
                            $i = 0;
							$this->db->where('sub_category',$row['sub_category']);
							$this->db->limit(5);
							$this->db->order_by('product_id','desc');
							$a = $this->db->get('product')->result_array();
							foreach ($a as $row2) {
							$now = $this->db->get_where('product',array('product_id'=>$row2['product_id']))->row();             
                        ?>
                        <dl class="dl-horizontal">
                            <dt>
                                <a href="<?php echo $this->crud_model->product_link($now->product_id); ?>">
                                    <img src="<?php echo $this->crud_model->file_view('product',$now->product_id,'','','thumb','src','multi','one'); ?>" alt="" />
                                </a>
                            </dt>
                            <dd>
                                <p>
                                    <a href="<?php echo $this->crud_model->product_link($now->product_id); ?>">
                                        <?php echo $now->title; ?>
                                    </a>
                                </p>
                                <p>
                                <?php if($this->crud_model->get_type_name_by_id('product',$now->product_id,'discount') > 0){ ?>
                                    <span>
                                        <?php echo currency().$this->crud_model->get_product_price($now->product_id); ?>
                                    </span>
                                    <span style=" text-decoration: line-through;color:#c9253c;">
                                        <?php echo currency().$now->sale_price; ?>
                                    </span>
                                <?php } else { ?>
                                    <span>
                                        <?php echo currency().$now->sale_price; ?>
                                    </span>
                                <?php } ?>
                                </p>
                            </dd>
                        </dl>
                        <?php	
                            }
                        ?>
                    </div><!--/posts-->
                    <!-- End Posts -->
                </div>
            </div><!--/end row-->
        </div>    
    </div>
    <!--=== End Product Body ===-->

    <?php
        $discus_id = $this->db->get_where('general_settings',array('type'=>'discus_id'))->row()->value;
        $fb_id = $this->db->get_where('general_settings',array('type'=>'fb_comment_api'))->row()->value;
        $comment_type = $this->db->get_where('general_settings',array('type'=>'comment_type'))->row()->value;
    ?>

    <!--=== Content Medium ===-->
    <div class="content-md container" style="">
        <div class="col-md-9">
    	<div class="panel panel-purple margin-bottom-40">
        <div class="panel-heading">
            <h2 class="panel-title heading heading-v4" style="font-weight:100;"><?php echo translate('detail_specifications');?></h2>
        </div>
        <table class="table table-bordered table-striped">
            <tbody>
                <?php if($row['brand'] !='') { ?>
                <tr>
                    <td style="text-align:center;"><?php echo translate('brand');?></td>
                    <td style="text-align:left;"><?php echo $this->db->get_where('brand',array('brand_id'=>$row['brand']))->row()->name; ?></td>
                </tr>
                <?php } if($row['model'] != '') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('model');?></td>
                    <td style="text-align:left;"><?php echo $row['model']; ?></td>
                </tr>
                <?php } if($row['processor'] != '') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('processor');?></td>
                    <td style="text-align:left;"><?php echo $row['processor']; ?></td>
                </tr>
                <?php } if($row['clock_speed'] != '') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('clock_speed');?></td>
                    <td style="text-align:left;"><?php echo $row['clock_speed']; ?></td>
                </tr>
                <?php } if($row['cache'] != '') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('cache');?></td>
                    <td style="text-align:left;"><?php echo $row['cache']; ?></td>
                </tr>
                <?php } if($row['display_size'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('display_size');?></td>
                    <td style="text-align:left;"><?php echo $row['display_size']; ?></td>
                </tr>
                <?php } if($row['display_type'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('display_type');?></td>
                    <td style="text-align:left;"><?php echo $row['display_type']; ?></td>
                </tr>
                <?php } if($row['ram'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('RAM');?></td>
                    <td style="text-align:left;"><?php echo $row['ram']; ?></td>
                </tr>
                <?php } if($row['ram_type'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('RAM_type');?></td>
                    <td style="text-align:left;"><?php echo $row['ram_type']; ?></td>
                </tr>
                <?php } if($row['storage'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('storage');?></td>
                    <td style="text-align:left;"><?php echo $row['storage']; ?></td>
                </tr>
                <?php } if($row['graphics_chipset'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('graphics_chipset');?></td>
                    <td style="text-align:left;"><?php echo $row['graphics_chipset']; ?></td>
                </tr>
                <?php } if($row['graphics_memory'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('graphics_memory');?></td>
                    <td style="text-align:left;"><?php echo $row['graphics_memory']; ?></td>
                </tr>
                <?php } if($row['optical_device'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('optical_device');?></td>
                    <td style="text-align:left;"><?php echo $row['optical_device']; ?></td>
                </tr>
                <?php } if($row['display_port'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('display_port');?></td>
                    <td style="text-align:left;"><?php echo $row['display_port']; ?></td>
                </tr>
                <?php } if($row['audio_port'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('audio_port');?></td>
                    <td style="text-align:left;"><?php echo $row['audio_port']; ?></td>
                </tr>
                <?php } if($row['usb_port'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('USB_port');?></td>
                    <td style="text-align:left;"><?php echo $row['usb_port']; ?></td>
                </tr>
                <?php } if($row['battery'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('battery');?></td>
                    <td style="text-align:left;"><?php echo $row['battery']; ?></td>
                </tr>
                <?php } if($row['backup_time'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('backup_time');?></td>
                    <td style="text-align:left;"><?php echo $row['backup_time']; ?></td>
                </tr>
                <?php } if($row['operating_system'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('operating_system');?></td>
                    <td style="text-align:left;"><?php echo $row['operating_system']; ?></td>
                </tr>
                <?php } if($row['weight'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('weight');?></td>
                    <td style="text-align:left;"><?php echo $row['weight']; ?></td>
                </tr>
                <?php } if($row['color'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('color');?></td>
                    <td style="text-align:left;"><?php echo $row['color']; ?></td>
                </tr>
                <?php } if($row['warranty'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('warranty');?></td>
                    <td style="text-align:left;"><?php echo $row['warranty']; ?></td>
                </tr>
                <?php } if($row['short_description'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('short_description	');?></td>
                    <td style="text-align:left;"><?php echo $row['short_description']; ?></td>
                </tr>
                <?php } if($row['long_description'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('long_description');?></td>
                    <td style="text-align:left;"><?php echo $row['long_description']; ?></td>
                </tr>
                <?php } if($row['product_id_no'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('product_ID');?></td>
                    <td style="text-align:left;"><?php echo $row['product_id_no']; ?></td>
                </tr>
                <?php } if($row['sale_price'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('price');?></td>
                    <td style="text-align:left;"><?php echo $row['sale_price']; ?></td>
                </tr>
                <?php } if($row['others'] !='') { ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('others');?></td>
                    <td style="text-align:left;"><?php echo $row['others']; ?></td>
                </tr>
                <?php } ?>
                
				<?php 
                    $a = $this->crud_model->get_additional_fields($row['product_id']);
                    if(count($a)>0){
						foreach ($a as $val) {
                ?>
                 <tr>
                    <td style="text-align:center;"><?php echo translate('others');?></td>
                    <td style="text-align:left;"><?php echo $row['others']; ?></td>
                </tr>
                <?php 
						}
					}
				?>
            </tbody>
        </table>
        </div>
        </div>
        <div class="col-md-3">
            <div class="sdbar posts margin-bottom-20">
                <h4 class="text_color center_text mr_top_0"><?php echo translate('similar_products'); ?></h4>
                <?php
                    $i = 0;
                    $this->db->where('sub_category',$row['sub_category']);
                    $this->db->limit(5);
                    $this->db->order_by('product_id','desc');
                    $a = $this->db->get('product')->result_array();
                    foreach ($a as $row2) {
                    $now = $this->db->get_where('product',array('product_id'=>$row2['product_id']))->row();             
                ?>
                <dl class="dl-horizontal">
                    <dt>
                        <a href="<?php echo $this->crud_model->product_link($now->product_id); ?>">
                            <img src="<?php echo $this->crud_model->file_view('product',$now->product_id,'','','thumb','src','multi','one'); ?>" alt="" />
                        </a>
                    </dt>
                    <dd>
                        <p>
                            <a href="<?php echo $this->crud_model->product_link($now->product_id); ?>">
                                <?php echo $now->title; ?>
                            </a>
                        </p>
                        <p>
                        <?php if($this->crud_model->get_type_name_by_id('product',$now->product_id,'discount') > 0){ ?>
                            <span>
                                <?php echo currency().$this->crud_model->get_product_price($now->product_id); ?>
                            </span>
                            <span style=" text-decoration: line-through;color:#c9253c;">
                                <?php echo currency().$now->sale_price; ?>
                            </span>
                        <?php } else { ?>
                            <span>
                                <?php echo currency().$now->sale_price; ?>
                            </span>
                        <?php } ?>
                        </p>
                    </dd>
                </dl>
                <?php	
                    }
                ?>
            </div>
        </div>
        
        
    </div><!--/end container-->    
    <!--=== End Content Medium ===-->

<?php
    }
?>

<script>
	$(document).ready(function() {
		$('#share').share({
			networks: ['facebook','googleplus','twitter','linkedin','tumblr','in1','stumbleupon','digg'],
			theme: 'square'
		});
	});
	
	$(window).load(function() {
	<?php
		if(count($mains) > 1){
	?>
	  $('#carousel').flexslider({
		animation: "slide",
		controlNav: false,
		animationLoop: false,
		slideshow: false,
		itemWidth: 100,
		itemMargin: 5,
		asNavFor: '#slider'
	  });
	<?php
		}
	?>
	 
	  $('#slider').flexslider({
		animation: "slide",
		controlNav: false,
		animationLoop: false,
		slideshow: false,
		sync: "#carousel"
	  });
	});

	$(function(){
		$('.zoom').zoome({hoverEf:'transparent',showZoomState:true,magnifierSize:[200,200]});
	});
	
	function destroyZoome(obj){
		if(obj.parent().hasClass('zm-wrap'))
		{
			obj.unwrap().next().remove();
		}
	}
	
</script>
<script type="text/javascript" src="//assets.pinterest.com/js/pinit.js"></script>
<script>
    $('body').on('click', '.quantity-button', function(){
        $('.add_to_cart').html('<i class="fa fa-shopping-cart"></i><?php echo translate('add_to_cart'); ?>');
    });
    $('body').on('change', '.optional', function(){
        $('.add_to_cart').html('<i class="fa fa-shopping-cart"></i><?php echo translate('add_to_cart'); ?>');
    });
</script>

<style>
    .heading_alt{
        font-size: 50px;
        font-weight: 100;
        color: #18BA9B;	
    }
</style>

