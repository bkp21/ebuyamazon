<div id="preloader">
	<center>
<style>#circularG {
	position:relative;
	width:100px;
	height:100px
}
.circularG {
	position:absolute;
	background-color:#470467;
	width:23px;
	height:23px;
	-moz-border-radius:15px !important;
	-moz-animation-name:bounce_circularG;
	-moz-animation-duration:1.2s;
	-moz-animation-iteration-count:infinite;
	-moz-animation-direction:normal;
	-webkit-border-radius:15px !important;
	-webkit-animation-name:bounce_circularG;
	-webkit-animation-duration:1.2s;
	-webkit-animation-iteration-count:infinite;
	-webkit-animation-direction:normal;
	-ms-border-radius:15px !important;
	-ms-animation-name:bounce_circularG;
	-ms-animation-duration:1.2s;
	-ms-animation-iteration-count:infinite;
	-ms-animation-direction:normal;
	-o-border-radius:15px !important;
	-o-animation-name:bounce_circularG;
	-o-animation-duration:1.2s;
	-o-animation-iteration-count:infinite;
	-o-animation-direction:normal;
	border-radius:15px !important;
	animation-name:bounce_circularG;
	animation-duration:1.2s;
	animation-iteration-count:infinite;
	animation-direction:normal;
}
#circularG_1 {
	left:0;
	top:39px;
	-moz-animation-delay:0.45s;
	-webkit-animation-delay:0.45s;
	-ms-animation-delay:0.45s;
	-o-animation-delay:0.45s;
	animation-delay:0.45s;
}
#circularG_2 {
	left:11px;
	top:11px;
	-moz-animation-delay:0.6s;
	-webkit-animation-delay:0.6s;
	-ms-animation-delay:0.6s;
	-o-animation-delay:0.6s;
	animation-delay:0.6s;
}
#circularG_3 {
	top:0;
	left:39px;
	-moz-animation-delay:0.75s;
	-webkit-animation-delay:0.75s;
	-ms-animation-delay:0.75s;
	-o-animation-delay:0.75s;
	animation-delay:0.75s;
}
#circularG_4 {
	right:11px;
	top:11px;
	-moz-animation-delay:0.9s;
	-webkit-animation-delay:0.9s;
	-ms-animation-delay:0.9s;
	-o-animation-delay:0.9s;
	animation-delay:0.9s;
}
#circularG_5 {
	right:0;
	top:39px;
	-moz-animation-delay:1.05s;
	-webkit-animation-delay:1.05s;
	-ms-animation-delay:1.05s;
	-o-animation-delay:1.05s;
	animation-delay:1.05s;
}
#circularG_6 {
	right:11px;
	bottom:11px;
	-moz-animation-delay:1.2s;
	-webkit-animation-delay:1.2s;
	-ms-animation-delay:1.2s;
	-o-animation-delay:1.2s;
	animation-delay:1.2s;
}
#circularG_7 {
	left:39px;
	bottom:0;
	-moz-animation-delay:1.35s;
	-webkit-animation-delay:1.35s;
	-ms-animation-delay:1.35s;
	-o-animation-delay:1.35s;
	animation-delay:1.35s;
}
#circularG_8 {
	left:11px;
	bottom:11px;
	-moz-animation-delay:1.5s;
	-webkit-animation-delay:1.5s;
	-ms-animation-delay:1.5s;
	-o-animation-delay:1.5s;
	animation-delay:1.5s;
}
@-moz-keyframes bounce_circularG {
	0% {
		-moz-transform:scale(1)
	}
	100% {
		-moz-transform:scale(.3)
	}
}
@-webkit-keyframes bounce_circularG {
	0% {
		-webkit-transform:scale(1)
	}
	100% {
		-webkit-transform:scale(.3)
	}
}
@-ms-keyframes bounce_circularG {
	0% {
		-ms-transform:scale(1)
	}
	100% {
		-ms-transform:scale(.3)
	}
}
@-o-keyframes bounce_circularG {
	0% {
		-o-transform:scale(1)
	}
	100% {
		-o-transform:scale(.3)
	}
}
@keyframes bounce_circularG {
	0% {
		transform:scale(1)
	}
	100% {
		transform:scale(.3)
	}
}
</style>

<div id="circularG" style="margin-top:20% !important;">
	<div id="circularG_1" class="circularG">
	</div>
	<div id="circularG_2" class="circularG">
	</div>
	<div id="circularG_3" class="circularG">
	</div>
	<div id="circularG_4" class="circularG">
	</div>
	<div id="circularG_5" class="circularG">
	</div>
	<div id="circularG_6" class="circularG">
	</div>
	<div id="circularG_7" class="circularG">
	</div>
	<div id="circularG_8" class="circularG">
	</div>
</div>
</center>
</div>

<style>
#preloader {
		height:100%;
		width:100%;
		background-color:white;
		position:fixed;
		top:0px;
		left:0px;
		overflow:hidden;
		z-index: 9999999;
}
</style>