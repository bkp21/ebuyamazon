<script src="http://www.google.com/jsapi"></script>
<script type="text/javascript" src="http://google-maps-utility-library-v3.googlecode.com/svn/tags/markerclusterer/1.0/src/markerclusterer.js"></script>

<div class="breadcrumbs">
    <div class="container">
        <h1 class="pull-left"><?php echo translate('our_contacts');?></h1>
    </div>
</div>

<div class="container content">
    <div class="row margin-bottom-60">
        <div class="col-md-8 col-sm-8">
            <!-- Google Map -->
            <div id="map" class="height-450">
            </div>
            <!-- End Google Map -->
        </div>
        <div class="col-md-4 col-sm-4">
            <input type="text" onkeyup="search_loc()" id="search">
            <div class="col-md-12 col-sm-12" id="result" style="height:500px; overflow:auto;">
            </div>
        </div>
    </div>

</div>

<script>
	var add_to_cart = '<?php echo translate('add_to_cart'); ?>';
	var valid_email = '<?php echo translate('must_be_a_valid_email_address'); ?>';
	var required = '<?php echo translate('required'); ?>';
	var sent = '<?php echo translate('message_sent!'); ?>';
	var incor = '<?php echo translate('incorrect_captcha!'); ?>';
	var required = '<?php echo translate('required'); ?>';
	var base_url = '<?php echo base_url(); ?>';
</script>

<script>
    var sale_details = [
    <?php
    if(!empty($resellers)){
        foreach($resellers as $row){
            $info = $this->db->get_where('reseller',array('reseller_id'=>$row['reseller_id']))->row();
            $address    = $info->address;
            $langlat    = explode(',',str_replace('(','',str_replace(')','',$info->lat_lang)));
            $reseller_name = $info->reseller_name;
    ?>
        ['<?php echo $address; ?>', <?php echo $langlat[0]; ?>, <?php echo $langlat[1]; ?>, '<?php echo $reseller_name; ?>'],
    <?php 
        }
    }
    ?>
    ];

    function search_loc(){
        var sale_details_new = [];
        var text = $('#search').val();
        if(text == ''){
            sale_details_new = sale_details;
        } else {
            for (i = 0; i < sale_details.length; i++) {
                var str = sale_details[i][0]+' '+sale_details[i][3];
                str = str.toLowerCase();
                if(str.search(text) !== -1){
                    sale_details_new.push([sale_details[i][0], sale_details[i][1], sale_details[i][2], sale_details[i][3]]);
                }
            }
        }
        var res ='';
        for (i = 0; i < sale_details_new.length; i++) {
            res += ''
                +'<div class="row">'
                +'<h3>'+sale_details_new[i][3]+'</h3>'
                +'<p>'+sale_details_new[i][0]+'</p>'
                +'</div>';
                +'<hr>';
        }
        $('#result').html(res);
        initialize(sale_details_new);
    }

    //var sale_details = [];    

    google.load('maps', '3', {
        other_params: 'sensor=false'
    });
    
    google.setOnLoadCallback(search_loc);
    
    var styles = [
        [{
            url: '../images/conv30.png',
            height: 27,
            width: 30,
            anchor: [3, 0],
            textColor: '#ff00ff',
            opt_textSize: 10
        }, {
            url: '../images/conv40.png',
            height: 36,
            width: 40,
            opt_anchor: [6, 0],
            opt_textColor: '#ff0000',
            opt_textSize: 11
        }, {
            url: '../images/conv50.png',
            width: 50,
            height: 45,
            opt_anchor: [8, 0],
            opt_textSize: 12
        }],
        [{
            url: '../images/heart30.png',
            height: 26,
            width: 30,
            opt_anchor: [4, 0],
            opt_textColor: '#ff00ff',
            opt_textSize: 10
        }, {
            url: '../images/heart40.png',
            height: 35,
            width: 40,
            opt_anchor: [8, 0],
            opt_textColor: '#ff0000',
            opt_textSize: 11
        }, {
            url: '../images/heart50.png',
            width: 50,
            height: 44,
            opt_anchor: [12, 0],
            opt_textSize: 12
        }]
    ];
    
    var markerClusterer = null;
    var map = null;
    var imageUrl = 'http://chart.apis.google.com/chart?cht=mm&chs=24x32&' +
        'chco=FFFFFF,008CFF,000000&ext=.png';
    
    //$('#resellers_list').on('shown.bs.modal', function (e) {
        
    //})

    function refreshMap(sale_details) {
        //if (markerClusterer) {
        //  markerClusterer.clearMarkers();
        //}
    
        var markers = [];
        var infoWindows = [];
    
        var markerImage = new google.maps.MarkerImage(imageUrl,
            new google.maps.Size(24, 32));
    
    
        var bound = new google.maps.LatLngBounds();
        // Loop through our array of markers & place each one on the map  
        for (i = 0; i < sale_details.length; i++) {
            var latLng = new google.maps.LatLng(sale_details[i][1], sale_details[i][2])
            var marker = new google.maps.Marker({
                position: latLng,
                draggable: false,
                icon: markerImage,
                animation: google.maps.Animation.DROP,
                infoWindowIndex: i
            });
    
            bound.extend(new google.maps.LatLng(sale_details[i][1], sale_details[i][2]));
    
            var content = '<div class="info_content">' +
                '<h3>' + sale_details[i][0] + '</h3>' +
                '<p>' + sale_details[i][3] + '</p>' +
                '</div>';
    
            var infoWindow = new google.maps.InfoWindow({
                content: content
            });
    
            google.maps.event.addListener(marker, 'click',
                function(event) {
                    infoWindows[this.infoWindowIndex].open(map, this);
                }
            );
    
            infoWindows.push(infoWindow);
            markers.push(marker);
        }
    
    
        var zoom = parseInt(16);
        var size = parseInt(40);
        var style = parseInt(-1);
    
        markerClusterer = new MarkerClusterer(map, markers, {
            maxZoom: zoom,
            gridSize: size,
            styles: styles[style]
        });
    
        //map.setCenter(bound.getCenter())
        //map1.setCenter(bound1.getCenter())
        map.fitBounds(bound);
    }
    
    function initialize(sale_details) {
        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 4,
            center: new google.maps.LatLng(23.91, 90.38),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
    
        refreshMap(sale_details);
    }
    
    function clearClusters(e) {
        e.preventDefault();
        e.stopPropagation();
        markerClusterer.clearMarkers();
    }

</script>
<style>
      #map-container {
        padding: 6px;
        border-width: 1px;
        border-style: solid;
        border-color: #ccc #ccc #999 #ccc;
        -webkit-box-shadow: rgba(64, 64, 64, 0.5) 0 2px 5px;
        -moz-box-shadow: rgba(64, 64, 64, 0.5) 0 2px 5px;
        box-shadow: rgba(64, 64, 64, 0.1) 0 2px 5px;
        width: 100%;
      }
      #map {
        width: 100%;
        height: 800px;
      }
      #actions {
        list-style: none;
        padding: 0;
      }
      #inline-actions {
        padding-top: 10px;
      }
      .item {
        margin-left: 20px;
      }

</style>