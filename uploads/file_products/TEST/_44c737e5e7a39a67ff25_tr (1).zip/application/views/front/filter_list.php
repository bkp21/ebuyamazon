
			<h1><?php echo translate('filter_by');?></h1>
			<?php
				foreach ($filters as $row) {
				    if($row['main'] == 'ok'){
			?>
			<div class="panel-group" id="accordion_<?php echo $row['no']; ?>" style="margin-bottom:-1px !important;    border-radius: 0px !important;">
				<div class="panel panel-default">
					<div class="panel-heading" style="padding: 0px 15px !important;border-bottom:1px solid #CCC;background: #FFFFF9;">
						<h2 class="panel-title" style="">
							<a data-toggle="collapse" data-parent="#accordion_<?php echo $row['no']; ?>" href="#collapse_<?php echo $row['no']; ?>"  style="padding: 0 !important;border:none !important;font-size: 18px !important;">
								<?php echo translate($row['name']);?>
								<i class="fa fa-angle-down pull-right" style="margin-top: 10px;"></i>
							</a>
						</h2>
					</div>
					<div id="collapse_<?php echo $row['no']; ?>" class="panel-collapse collapse in">
						<div class="panel-body sky-form" style="padding: 0px 10px; !important;">
							<ul class="list-unstyled checkbox-list">
								<li style="margin-top: 0px !important;">
								   <label class="radio state-success">
										<input type="radio" name="check_<?php echo $row['no']; ?>"  onclick="filter_this();"
											value="0" checked />
										<i class="rounded-x" style="font-size:30px !important;"></i>
										<?php echo translate('any'); ?> 
									</label> 
								</li>
								<?php
									$field_vals = $this->crud_model->cat_field_common_val($category,$row['no']);
									foreach($field_vals as $val=>$count)
									{
								?>
								<li style="margin-top: 0px !important;">
								   <label class="radio state-success">
										<input type="radio" name="check_<?php echo $row['no']; ?>"  onclick="filter_this();"
											value="<?php echo $val; ?>" />
										<i class="rounded-x" style="font-size:30px !important;"></i>
										<?php echo $val; ?>
										<small>
											(<?php echo $count; ?>)
										</small>
									</label> 
								</li>
								<?php
									}
								?>
							</ul>        
						</div>
					</div>
				</div>
			</div><!--/end panel group-->
            <?php
				    }
            	}
            ?>
			<div class="panel-group" id="accordion_v4">
				<div class="panel panel-default">
					<div class="panel-heading" style="padding: 0px 15px !important;border-bottom:1px solid #CCC;background: #FFFFF9;">
						<h2 class="panel-title" style="">
							<a data-toggle="collapse" data-parent="#accordion_v4" href="#collapseFour"  style="padding: 0 !important;border:none !important;font-size: 18px !important;">
								<?php echo translate('price');?>
								<i class="fa fa-angle-down pull-right" style="margin-top: 10px;"></i>
							</a>
						</h2>
					</div>
					<div id="collapseFour" class="panel-collapse collapse in">
						<div class="panel-body" id="rangea">
							<?php
								$min = $this->crud_model->get_range_lvl('category', $category, "min");
						        $max = $this->crud_model->get_range_lvl('category', $category, "max");
					            $start = $min;
					            $end = $max;  		        
						        $return = '' . '<input type="text" id="rangelvla" value="" name="range" />' . '<script>' . '	$("#rangelvla").ionRangeSlider({' . '		hide_min_max: false,' . '		keyboard: true,' . '		min:' . $min . ',' . '		max:' . $max . ',' . '		from:' . $start . ',' . '		to:' . $end . ',' . '		type: "double",' . '		step: 1,' . '		prefix: "'.currency().'",' . '		grid: true,' . '		onFinish: function (data) {' . "			filter_this();" . '		}' . '	});' . '</script>';
						        echo $return;
					        ?>
						</div>
					</div>
				</div>
			</div>
