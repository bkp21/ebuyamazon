<div class="container" style="margin-bottom: -40px;">
    <div class="heading heading-v1 margin-bottom-20">
        <h2><?php echo translate('featured_product');?></h2>
        <p></p>
    </div>
    
    <div class="illustration-v2 margin-bottom-60">
        <ul class="list-inline owl-slider-v2">
        <?php
            foreach($featured_data as $row1)
            {
                if($this->crud_model->is_publishable($row1['product_id'])){
        ?>
            <li class="item custom_item">
                <div class="product-img">
                    <a href="<?php echo $this->crud_model->product_link($row1['product_id']); ?>">
                        <div class="shadow" 
                            style="background: url('<?php echo $this->crud_model->file_view('product',$row1['product_id'],'','','thumb','src','multi','one'); ?>') no-repeat center center; 
                                background-size: 100% auto;">
                        </div>
                    </a>
                    
                    <a class="add-to-cart" href="<?php echo $this->crud_model->product_link($row1['product_id']); ?>">
                            <?php echo translate('details');?>
                    </a>
                </div>
                <div class="product-description product-description-brd">
                    <div class="overflow-h margin-bottom-5">
                        <div class="col-md-12 pull-left" style="padding:0px;">
                        	
                            <h4 class="title-price"><a href="<?php echo $this->crud_model->product_link($row1['product_id']); ?>"><?php echo $row1['title'] ?></a></h4>
                        </div>
                        <div class="col-md-12 product-price" style="padding:0px;">
                            <span class="title-price"><?php echo currency().$row1['sale_price']; ?></span>
                        </div>
                    </div>
                    <div class="col-md-12 pull-left" style="padding:0px;margin-top: 4px;">
                        <span class="gender text-uppercase text-center"><?php echo $this->crud_model->get_type_name_by_id('category',$row1['category'],'category_name'); ?></span>
                    </div>
                    <div class="col-md-12 pull-left" style="padding:0px;margin-top: 4px;">
                        <span class="gender text-center"><?php echo $this->crud_model->short_html($row1['product_id'],', ',' : '); ?></span>
                    </div>
                    
                    <div class="col-md-10" style="padding:0px;">
                    <?php 
                        $wish = $this->crud_model->is_wished($row1['product_id']); 
                    ?>
                        <ul class="list-inline product-ratings col-md-2 col-sm-2 col-xs-2 tooltips pull-left"
                             data-original-title="<?php if($wish == 'yes'){ ?><?php echo translate('added_to_favourite');?><?php } else { ?><?php echo translate('add_to_favourite');?><?php } ?>" 
                                data-toggle="tooltip" data-placement="top" >
                            <li class="like-icon">
                                <span data-pid='<?php echo $row1['product_id']; ?>'
                                    class="<?php if($wish == 'yes'){ ?>wished_it<?php } else {?>wish_it<?php } ?>">
                                    <i class="fa fa-thumbs-up"></i>
                                </span>
                            </li>
                        </ul>
                    </div>  
                    <div class="col-md-2 pull-right" style="padding:0px;">
                    	<?php if($this->crud_model->is_compared($row1['product_id'])=='yes'){ ?>
                            <span data-original-title="<?php echo translate('added_to_compared');?>" data-toggle="tooltip" data-placement="right" class="tooltips btn_compared wished_it">
                                <i class="fa fa-random"></i>
                            </span>
                        <?php } else { ?>
                            <span data-original-title="<?php echo translate('add_to_compare');?>" data-toggle="tooltip" data-placement="left" data-pid='<?php echo $row1['product_id']; ?>' class="tooltips btn_compare" style="cursor:pointer">
                                <i class="fa fa-random"></i>
                            </span>
                        <?php } ?>
                    </div>
                    <div class="row">
                        <div class="col-md-7 pull-left" style="">
                           <button class="btn-u btn-u-xs btn-u-blue" type="button"><i class="fa fa-thumbs-up"></i> <?php echo translate('favourite');?></button>
                        </div>
                        <div class="col-md-5 pull-right" style="">
                        	<button class="btn-u btn-u-xs btn-u-sea" type="button"><i class="fa fa-random"></i> <?php echo translate('compare');?></button>
                        </div>
                    </div>
                </div>
            </li>   
        <?php
                }
            }
        ?>
        </ul>
    </div>
</div>

<!--=== home banner ===-->
<div class="container margin-bottom-20 margin-top-20">
	<?php
		$place = 'after_slider';
        $query = $this->db->get_where('banner',array('page'=>'home', 'place'=>$place, 'status' => 'ok'));
        $banners = $query->result_array();
        if($query->num_rows() > 0){
            $r = 12/$query->num_rows();
        }
        foreach($banners as $row){
    ?>
        <a href="<?php echo $row['link']; ?>" >
            <div class="col-md-<?php echo $r; ?> md-margin-bottom-30">
                <div class="overflow-h">
                    <div class="illustration-v1 illustration-img1">
                        <div class="illustration-bg banner_<?php echo $query->num_rows(); ?>" 
                            style="background:url('<?php echo $this->crud_model->file_view('banner',$row['banner_id'],'','','no','src') ?>') no-repeat center center; background-size: 100% auto;" >
                        </div>    
                    </div>
                </div>    
            </div>
        </a>
    <?php
        }
    ?>
</div>
<!--=== home banner ===-->

<!--=== home banner ===-->
<div class="container margin-bottom-30">
	<?php
		$place = 'after_featured';
        $query = $this->db->get_where('banner',array('page'=>'home', 'place'=>$place, 'status' => 'ok'));
        $banners = $query->result_array();
        if($query->num_rows() > 0){
            $r = 12/$query->num_rows();
        }
        foreach($banners as $row){
    ?>
        <a href="<?php echo $row['link']; ?>" >
            <div class="col-md-<?php echo $r; ?> md-margin-bottom-30">
                <div class="overflow-h">
                    <div class="illustration-v1 illustration-img1">
                        <div class="illustration-bg banner_<?php echo $query->num_rows(); ?>" 
                            style="background:url('<?php echo $this->crud_model->file_view('banner',$row['banner_id'],'','','no','src') ?>') no-repeat center center; background-size: 100% auto;" >
                            
                        </div>    
                    </div>
                </div>    
            </div>
        </a>
    <?php
        }
    ?>
</div>

<div class="container margin-top-20">
	<?php
		$place = 'after_search';
        $query = $this->db->get_where('banner',array('page'=>'home', 'place'=>$place, 'status' => 'ok'));
        $banners = $query->result_array();
        if($query->num_rows() > 0){
            $r = 12/$query->num_rows();
        }
        foreach($banners as $row){
    ?>
        <a href="<?php echo $row['link']; ?>" >
            <div class="col-md-<?php echo $r; ?> md-margin-bottom-30">
                <div class="overflow-h margin-top-5">
                    <div class="illustration-v1 illustration-img1">
                        <div class="illustration-bg banner_<?php echo $query->num_rows(); ?>" 
                            style="background:url('<?php echo $this->crud_model->file_view('banner',$row['banner_id'],'','','no','src') ?>') no-repeat center center; background-size: 100% auto;" >
                            
                        </div>    
                    </div>
                </div>    
            </div>
        </a>
    <?php
        }
    ?>
</div>  

<div class="container content">
    
    <!--=== Illustration v4 ===-->
    <div class="row illustration-v4 margin-bottom-20">
        <div class="col-md-4">
            <div class="heading margin-bottom-10 margin-top-20">
                <h2><?php echo  translate('latest_products'); ?></h2>
            </div>
            <?php
                $this->db->order_by('product_id','desc');
                $this->db->where('status','ok');
                $latest = $this->db->get('product')->result_array();
                $i = 0;
                foreach ($latest as $row2){
                    if($this->crud_model->is_publishable($row2['product_id'])){
                        $i++;
                        if($i <= 3){

            ?>
            <div class="thumb-product">
                <div class="thumb-product-img" style="background:url('<?php echo $this->crud_model->file_view('product',$row2['product_id'],'','','thumb','src','multi','one'); ?>') no-repeat center center; background-size: 100% auto;"></div>
                <div class="thumb-product-in">
                    <h4><a href="<?php echo $this->crud_model->product_link($row1['product_id']); ?>"><?php echo $row2['title'] ?></a></h4>
                    <span class="thumb-product-type"><?php echo $this->crud_model->get_type_name_by_id('category',$row2['category'],'category_name'); ?></span>
                </div>
                <ul class="list-inline overflow-h">
                <?php if($this->crud_model->get_type_name_by_id('product',$row2['product_id'],'discount') > 0){ ?>
                    <li class="thumb-product-price">
                        <?php echo currency().$this->crud_model->get_product_price($row2['product_id']); ?>
                    </li>
                    <li class="thumb-product-price line-through">
                        <?php echo currency().$row2['sale_price']; ?>
                    </li>
                <?php } else { ?>
                    <li class="thumb-product-price">
                        <?php echo currency().$row2['sale_price']; ?>
                    </li>
                <?php } ?>
                    <li class="thumb-product-purchase">
                        <?php if($this->crud_model->is_wished($row2['product_id'])=='yes'){ ?>
                            <span data-original-title="<?php echo translate('added_to_wishlist');?>" data-toggle="tooltip" data-placement="left" class="tooltips wished_it">
                                <i class="fa fa-heart"></i>
                            </span>
                        <?php } else { ?>
                            <span data-original-title="<?php echo translate('add_to_wishlist');?>" data-toggle="tooltip" data-placement="left" data-pid='<?php echo $row2['product_id']; ?>' class="tooltips wish_it">
                                <i class="fa fa-heart"></i>
                            </span>
                        <?php } ?>
                        |
                        <?php if($this->crud_model->is_compared($row2['product_id'])=='yes'){ ?>
                            <span data-original-title="<?php echo translate('added_to_compared');?>" data-toggle="tooltip" data-placement="left" class="tooltips btn_compared wished_it">
                                <i class="fa fa-exchange"></i>
                            </span>
                        <?php } else { ?>
                            <span data-original-title="<?php echo translate('add_to_compare');?>" data-toggle="tooltip" data-placement="left" data-pid='<?php echo $row2['product_id']; ?>' class="tooltips btn_compare" style="cursor:pointer;">
                                <i class="fa fa-exchange"></i>
                            </span>
                        <?php } ?>
                    </li>
                </ul>    
            </div>
            <?php
                        }
                    }
                }
            ?>
        </div>
        
        <div class="col-md-4">
            <div class="heading margin-bottom-10 margin-top-20">
                <h2><?php echo  translate('most_sold'); ?></h2>
            </div>
            <?php
                $i = 0;
                $most_popular = $this->crud_model->most_sold_products();
                foreach ($most_popular as $row2){
                    $i++;
                    if($i <= 3){
                    if($this->crud_model->is_publishable($most_popular[$i]['id'])){
                        $now = $this->db->get_where('product',array('product_id'=>$most_popular[$i]['id']))->row();
            ?>
            <div class="thumb-product">
                <div class="thumb-product-img" style="background:url('<?php echo $this->crud_model->file_view('product',$now->product_id,'','','thumb','src','multi','one'); ?>') no-repeat center center; background-size: 100% auto;"></div>
                <div class="thumb-product-in">
                    <h4><a href="<?php echo $this->crud_model->product_link($now->product_id); ?>"><?php echo $now->title; ?></a></h4>
                    <span class="thumb-product-type"><?php echo $this->crud_model->get_type_name_by_id('category',$now->category,'category_name'); ?></span>
                </div>
                <ul class="list-inline overflow-h">
                <?php if($this->crud_model->get_type_name_by_id('product',$now->product_id,'discount') > 0){ ?>
                    <li class="thumb-product-price">
                        <?php echo currency().$this->crud_model->get_product_price($now->product_id); ?>
                    </li>
                    <li class="thumb-product-price line-through">
                        <?php echo currency().$now->sale_price; ?>
                    </li>
                <?php } else { ?>
                    <li class="thumb-product-price">
                        <?php echo currency().$now->sale_price; ?>
                    </li>
                <?php } ?>
                    <li class="thumb-product-purchase">
                        <?php if($this->crud_model->is_wished($now->product_id)=='yes'){ ?>
                            <span data-original-title="<?php echo translate('added_to_wishlist');?>" data-toggle="tooltip" data-placement="left" class="tooltips wished_it">
                                <i class="fa fa-heart"></i>
                            </span>
                        <?php } else { ?>
                            <span data-original-title="<?php echo translate('add_to_wishlist');?>" data-toggle="tooltip" data-placement="left" data-pid='<?php echo $now->product_id; ?>' class="tooltips wish_it">
                                <i class="fa fa-heart"></i>
                            </span>
                        <?php } ?>
                        |
                        <?php if($this->crud_model->is_compared($now->product_id)=='yes'){ ?>
                            <span data-original-title="<?php echo translate('added_to_compared');?>" data-toggle="tooltip" data-placement="left" class="tooltips btn_compared wished_it">
                                <i class="fa fa-exchange"></i>
                            </span>
                        <?php } else { ?>
                            <span data-original-title="<?php echo translate('add_to_compare');?>" data-toggle="tooltip" data-placement="left" data-pid='<?php echo $now->product_id; ?>' class="tooltips btn_compare" style="cursor:pointer;">
                                <i class="fa fa-exchange"></i>
                            </span>
                        <?php } ?>
                    </li>
                </ul>    
            </div>
            <?php
                        }
                    }
                }
            ?>
            
        </div>
        
        <div class="col-md-4">
            <div class="heading margin-bottom-10 margin-top-20">
                <h2><?php echo  translate('most_viewed_products'); ?></h2>
            </div>
            <?php
                $this->db->order_by('number_of_view','desc');
                $this->db->where('status','ok');
                $most_viewed = $this->db->get('product')->result_array();
                $i = 0;
                foreach ($most_viewed as $row2){
                    if($this->crud_model->is_publishable($row2['product_id'])){
                        $i++;
                        if($i<=3){
            ?>
            <div class="thumb-product">
                <div class="thumb-product-img" style="background:url('<?php echo $this->crud_model->file_view('product',$row2['product_id'],'','','thumb','src','multi','one'); ?>') no-repeat center center; background-size: 100% auto;"></div>
                <div class="thumb-product-in">
                    <h4><a href="<?php echo $this->crud_model->product_link($row2['product_id']); ?>"><?php echo $row2['title'] ?></a></h4>
                    <span class="thumb-product-type"><?php echo $this->crud_model->get_type_name_by_id('category',$row2['category'],'category_name'); ?></span>
                </div>
                <ul class="list-inline overflow-h">
                <?php if($this->crud_model->get_type_name_by_id('product',$row2['product_id'],'discount') > 0){ ?>
                    <li class="thumb-product-price">
                        <?php echo currency().$this->crud_model->get_product_price($row2['product_id']); ?>
                    </li>
                    <li class="thumb-product-price line-through">
                        <?php echo currency().$row2['sale_price']; ?>
                    </li>
                <?php } else { ?>
                    <li class="thumb-product-price">
                        <?php echo currency().$row2['sale_price']; ?>
                    </li>
                <?php } ?>
                    <li class="thumb-product-purchase">
                        <?php if($this->crud_model->is_wished($row2['product_id'])=='yes'){ ?>
                            <span data-original-title="<?php echo translate('added_to_wishlist');?>" data-toggle="tooltip" data-placement="left" class="tooltips wished_it">
                                <i class="fa fa-heart"></i>
                            </span>
                        <?php } else { ?>
                            <span data-original-title="<?php echo translate('add_to_wishlist');?>" data-toggle="tooltip" data-placement="left" data-pid='<?php echo $row2['product_id']; ?>' class="tooltips wish_it">
                                <i class="fa fa-heart"></i>
                            </span>
                        <?php } ?>
                        |
                        <?php if($this->crud_model->is_compared($row2['product_id'])=='yes'){ ?>
                            <span data-original-title="<?php echo translate('added_to_compared');?>" data-toggle="tooltip" data-placement="left" class="tooltips btn_compared wished_it">
                                <i class="fa fa-exchange"></i>
                            </span>
                        <?php } else { ?>
                            <span data-original-title="<?php echo translate('add_to_compare');?>" data-toggle="tooltip" data-placement="left" data-pid='<?php echo $row2['product_id']; ?>' class="tooltips btn_compare" style="cursor:pointer;">
                                <i class="fa fa-exchange"></i>
                            </span>
                        <?php } ?>
                    </li>
                </ul>    
            </div>
            <?php
                        }
                    }
                }
            ?>
        </div>
    </div><!--/end row-->

    <div class="row">
		<?php
            $i = 0;
            $brands = json_decode($this->crud_model->get_type_name_by_id('ui_settings','13','value'));
            if($brands){
		?>
        <!--=== Sponsors ===-->
        <div class="container content">
            <div class="heading margin-bottom-20">
                <h2><?php echo translate('our_available_brands'); ?></h2>
            </div>
    
            <ul class="list-inline owl-sponsor">
            	<?php
					foreach($brands as $row1)
					{
						$brand = $this->db->get_where('brand',array('brand_id'=>$row1))->result_array();
						foreach($brand as $row)
						{
						$i++;
				?>
                        <li class="item <?php if($i==1){ ?>first-child<?php } ?>">
                            <img src="<?php echo $this->crud_model->file_view('brand',$row['brand_id'],'','','no','src','','','.png') ?>" alt="" style="width: 100%;">
                        </li>
                <?php
							}
						}
					}
				?>
            </ul><!--/end owl-carousel-->
        </div>
	</div>
</div>


<style>
	
	div.shadow {
		max-height:190px;
		min-height:190px;
		overflow:hidden;
		-webkit-transition: all .4s ease;
		-moz-transition: all .4s ease;
		-o-transition: all .4s ease;
		-ms-transition: all .4s ease;
		transition: all .4s ease;
	}
	.shadow:hover {
		background-size: 110% auto !important;
	}
	
	.custom_item{
	  border: 1px solid #ccc;
	  border-radius: 4px !important;
	  transition: all .2s ease-in-out;
	   margin-top:10px !important;	
	}
	.custom_item:hover{
	  webkit-transform: translate3d(0, -5px, 0);
	  -moz-transform: translate3d(0, -5px, 0);
	  -o-transform: translate3d(0, -5px, 0);
	  -ms-transform: translate3d(0, -5px, 0);
	  transform: translate3d(0, -5px, 0);
	  border:1px solid #002AF7;
	}
	.tab_hov{
	    transition: all .5s ease-in-out;	
	}
	.tab_hov:hover{
		opacity:0.7;
		transition: all .5s ease-in-out;
	}
	.tab_hov:active{
		opacity:0.7;
	}
</style>