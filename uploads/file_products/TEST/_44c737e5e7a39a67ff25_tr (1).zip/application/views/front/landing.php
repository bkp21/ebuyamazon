<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Welcome - Tech Republic</title>
	<meta name="viewport" content="initial-scale=1, maximum-scale=1">
	<link href="http://fonts.googleapis.com/css?family=Oswald:300,400,700" rel="stylesheet" type="text/css">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,300,400italic,400,600italic,600,700italic,700,800italic,800" rel="stylesheet" type="text/css">
	<link href='http://fonts.googleapis.com/css?family=Indie+Flower' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
	<!--[if lt IE 9]>
		<script src="../documentation/assets/js/html5.js"></script>
	<![endif]-->

    <link rel="shortcut icon" href="<?php echo base_url(); ?>uploads/others/favicon.png">
	<!-- LayerSlider stylesheet -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>template/front/layerslider/css/layerslider.css" type="text/css">
	<!-- External libraries: jQuery & GreenSock -->
	<script src="<?php echo base_url(); ?>template/front/layerslider/js/jquery.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>template/front/layerslider/js/greensock.js" type="text/javascript"></script>
	<!-- LayerSlider script files -->
	<script src="<?php echo base_url(); ?>template/front/layerslider/js/layerslider.transitions.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>template/front/layerslider/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>

	<style>
		body, html {
			margin: 0;
			padding: 0;
			width: 100%;
			height: 100%;
			overflow: hidden;
			background: black !important;
		}

		#layerslider * {
			font-family: Lato, 'Open Sans', sans-serif;
			font-weight: 300;
		}

		#layerslider h1 {
			font-size: 30px;
			color: #eee;
		}
		#layerslider h2 {
			font-size: 40px;
			color: #111;
		}

		#layerslider {
			position: absolute;
			z-index: 1;
		}

		#example-wrapper {
			z-index: 2;
			position: relative;
			top: 50%;
		}

	</style>

</head>
<body class="nobg">
	<div id="layerslider" style="width: 100%;
		 height: 100%;">
		<div class="ls-slide" data-ls="slidedelay: 20000;transition2d: all;">
		<img src="<?php echo base_url(); ?>/uploads/slider_image/landing/header_bg1.jpg" class="ls-bg" alt="Slide background"/>
       
        
		<img class="ls-l" style="top:50%; 
		left:30%;
        width:448px;
		white-space: nowrap;
		" data-ls="offsetxin:0;
		durationin:4000;
		delayin:1500;
		offsetxout:0;
		durationout:2500;
		" src="<?php echo base_url(); ?>/uploads/slider_image/landing/map.png"/>
        
        <img class="ls-l" style="top:50%; 
		left:30%;
        width:450px;
		color:white;
		white-space: nowrap;
		" data-ls="offsetxin:0;
		durationin:2500;
		delayin:500;
		offsetxout:0;
		durationout:2500;
		" src="<?php echo base_url(); ?>/uploads/slider_image/landing/map_border.png"/>
        
        
        
       <img class="ls-l" style="top:40%;
		left:60%;
		white-space: nowrap;
		" data-ls="offsetxin:0;
		durationin:3500;
		delayin:3000;
		offsetxout:0;
		" src="<?php echo base_url(); ?>/uploads/slider_image/landing/logo.png" alt="">
        
        <img class="ls-l" 
        style="top:100px;
        left:28%;
        white-space: nowrap;" 
        data-ls="offsetxin:0;
        durationin:1500;
        delayin:4000;
        easingin:linear;
        scalexin:0;
        scaleyin:0;
        offsetxout:0;
        durationout:1500;
        showuntil:1;
        easingout:linear;
        scalexout:2;
        scaleyout:2;" 
        src="<?php echo base_url(); ?>/uploads/slider_image/landing/circle.png" alt="">
        
        <img class="ls-l" 
        style="top:100px;
        left:28%;
        white-space: nowrap;" 
        data-ls="offsetxin:0;
        durationin:1500;
        delayin:5000;
        easingin:linear;
        scalexin:0;
        scaleyin:0;
        offsetxout:0;
        durationout:1500;
        showuntil:1;
        easingout:linear;
        scalexout:2;
        scaleyout:2;" 
        src="<?php echo base_url(); ?>/uploads/slider_image/landing/circle.png" alt="">
        
        <img class="ls-l" 
        style="top:100px;
        left:28%;
        white-space: nowrap;" 
        data-ls="offsetxin:0;
        durationin:1500;
        delayin:6000;
        easingin:linear;
        scalexin:0;
        scaleyin:0;
        offsetxout:0;
        durationout:1500;
        showuntil:1;
        easingout:linear;
        scalexout:2;
        scaleyout:2;" 
        src="<?php echo base_url(); ?>/uploads/slider_image/landing/circle.png" alt="">
        
        <img class="ls-l" 
        style="top:100px;
        left:28%;
        white-space: nowrap;" 
        data-ls="offsetxin:0;
        durationin:1500;
        delayin:7000;
        easingin:linear;
        scalexin:0;
        scaleyin:0;
        offsetxout:0;
        durationout:1500;
        showuntil:1;
        easingout:linear;
        scalexout:2;
        scaleyout:2;" 
        src="<?php echo base_url(); ?>/uploads/slider_image/landing/circle.png" alt="">
        
       <p class="ls-l" 
        style="top:60%;
        left:62%;
        font-weight: 300; 
        background: white; 
        background: rgba(255, 255, 255, 0.85);
        height:40px;
        padding-right:20px;
        padding-left:20px;
        font-size:27px;
        line-height:37px;
        color:#0066B1;
        cursor:pointer;
        white-space: nowrap;"
         data-ls="offsetxin:0;
         rotatexin:-70;
         scalexin:3;
         scaleyin:3;
         offsetxout:0;
         rotatexout:70;
         scalexout:0.5;
         scaleyout:0.5;
        durationin:1500;
        delayin:7000;">
		<a href="<?php echo base_url(); ?>index.php/home" style="text-decoration:none;"/>Browse main site</a>
		</p>
                
        
        
		</div>
	</div>
	<!-- Initializing the slider -->
	<script>
		jQuery("#layerslider").layerSlider({
			pauseOnHover: false,
			skinsPath: '../layerslider/skins/',
			skin: 'noskin',
			showCircleTimer: false
		});
		$(document).ready(function(){
			setTimeout(function(){ 
				location.replace("<?php echo base_url(); ?>index.php/home");
			}, 30000);
		});
	</script>
</body>
</html>
