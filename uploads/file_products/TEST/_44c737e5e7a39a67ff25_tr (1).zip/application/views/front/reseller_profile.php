<?php
     foreach($user_info as $row)
        {
?>
                    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=false"></script>
    <!--=== Profile ===-->
    <div class="profile container content">
    	<div class="row">
            <!--Left Sidebar-->
            <div class="col-md-3 md-margin-bottom-40">
                <?php if(file_exists('uploads/reseller_image/reseller_'.$row['reseller_id'].'.png')){ ?>
                    <img class="img-responsive profile-img margin-bottom-20" src="<?php echo base_url(); ?>uploads/reseller_image/reseller_<?php echo $row['reseller_id']; ?>.png" alt="reseller_Image">
                <?php } else { ?>
                    <img class="img-responsive profile-img margin-bottom-20" src="<?php echo base_url(); ?>uploads/reseller_image/default.png" >
                <?php } ?>
                    <table class="table">
                    <tbody>
                        <tr>
                            <td colspan="2">
                                <center><h4><?php echo translate('personal_information');?></h4></center>
                            </td>                          
                        </tr>
                        <tr>
                            <th><?php echo translate('reseller_name');?></th>
                            <td> <?php echo $row['reseller_name'];?></td>                          
                        </tr> 
                        <tr>
                            <th><?php echo translate('proprietor');?></th>
                            <td> <?php echo $row['proprietor'];?></td>                          
                        </tr> 
                        <tr>
                            <th><?php echo translate('email');?></th>
                            <td><?php echo $row['email'];?></td>                          
                        </tr> 
                        <tr>
                            <th><?php echo translate('phone');?></th>
                            <td><?php echo $row['phone'];?></td>                          
                        </tr> 
                        <tr>
                            <th><?php echo translate('mobile');?></th>
                            <td><?php echo $row['mob'];?></td>                          
                        </tr> 
                        <tr>
                            <th><?php echo translate('address');?></th>
                            <td><?php echo $row['address'];?></td>                          
                        </tr> 
                        <tr>
                            <th><?php echo translate('website');?></th>
                            <td><?php echo $row['web'];?></td>                       
                        </tr>   
                    </tbody>
                </table>
                    
                    
            </div>
            <!--End Left Sidebar-->
            
            <div class="col-md-9">
                <!--Profile Body-->
                <div class="profile-body">
                	<div class="row margin-bottom-30">
                        <?php /* ?>
                        <div class="col-sm-6 sm-margin-bottom-20">
                            <div class="service-block-v3 service-block-u">
                                <i class="fa fa-shopping-cart"></i>
                                <span class="service-heading">
                                	<?php echo translate('total_purchase');?>
                                </span>
                                <span class="counter">
                                	<?php echo currency().$this->crud_model->user_total(0); ?>
                                </span>
                                
                                <div class="clearfix margin-bottom-10"></div>
                                
                                <div class="row margin-bottom-20">
                                    <div class="col-xs-6 service-in">
                                        <small><?php echo translate('last_7_days');?></small>
                                        <h4 class="counter">
											<?php echo currency().$this->crud_model->user_total(7); ?>
                                        </h4>
                                    </div>
                                    <div class="col-xs-6 text-right service-in">
                                        <small><?php echo translate('last_30_days');?></small>
                                        <h4 class="counter">
											<?php echo currency().$this->crud_model->user_total(30); ?>
                                        </h4>
                                    </div>
                                </div>            
                            </div>
                        </div>
                        
                        <div class="col-sm-6">
                            <div class="service-block-v3 service-block-blue">
                                <i class="fa fa-heart"></i>
                                <span class="service-heading"><?php echo translate('wished_products');?></span>
                                <span class="counter">
                                	<?php echo $this->crud_model->reseller_wished(); ?>
                                </span>
                                
                                <div class="clearfix margin-bottom-10"></div>
                                
                                <div class="row margin-bottom-20">
                                    <div class="col-xs-6 service-in">
                                        <small><?php echo translate('reseller_since');?></small>
                                        <h4 class="counter">
                                        	<?php
                                            	echo date('d M, Y',$row['creation_date']);
											?>
                                        </h4>
                                    </div>
                                    <div class="col-xs-6 text-right service-in">
                                        <small><?php echo translate('last_login');?></small>
                                        <h4 class="counter">
                                        	<?php
                                            	echo date('d M, Y',$row['last_login']);
											?>
                                        </h4>
                                    </div>
                                </div>            
                            </div>
                        </div>
                        <?php */ ?>
                    </div><!--/end row-->

                    <div class="tab-v2">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab-2" data-toggle="tab"><?php echo translate('edit_info');?></a></li>
                            <li class=""><a href="#tab-3" data-toggle="tab"><?php echo translate('change_password');?></a></li>
                        </ul>                
                        <div class="tab-content">

                            <div class="tab-pane fade active in" id="tab-2">
                                <div class="row margin-bottom-40">
                                	<div class="col-md-12">
                        				<!-- Reg-Form -->
										<?php
                                            echo form_open(base_url() . 'index.php/home/registration/reseller_update_info/', array(
                                                'class' => 'sky-form log-reg-v3',
                                                'method' => 'post',
                                                'enctype' => 'multipart/form-data',
                                                'id' => 'sky-form4'
                                            ));
                                        ?>    
                                        	<?php
											foreach($user_info as $row)
												{
											?>
                                            <fieldset>                  
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-user"></i>
                                                        <input type="text" name="reseller_name" class="required" value="<?php echo $row['reseller_name'];?>">
                                                        <b class="tooltip tooltip-right"><?php echo translate('re-write reseller_name'); ?></b>
                                                    </label>
                                                </section> 

                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-user"></i>
                                                        <input type="text" name="proprietor" class="required" value="<?php echo $row['proprietor'];?>">
                                                        <b class="tooltip tooltip-right"><?php echo translate('re-write proprietor_name'); ?></b>
                                                    </label>
                                                </section>
                                                
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-phone"></i>
                                                        <input type="text" name="phone" value="<?php echo $row['phone'];?>" >
                                                        <b class="tooltip tooltip-right">
                                                            <?php echo translate('re-write_your_phone_number'); ?>
                                                                </b>
                                                    </label>
                                                </section>
                                                
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-phone"></i>
                                                        <input type="text" name="mob" value="<?php echo $row['mob'];?>" >
                                                        <b class="tooltip tooltip-right">
                                                            <?php echo translate('re-write_your_mobile_number'); ?>
                                                                </b>
                                                    </label>
                                                </section>
                                                
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-phone"></i>
                                                        <input type="text" name="web" value="<?php echo $row['web'];?>" >
                                                        <b class="tooltip tooltip-right">
                                                            <?php echo translate('re-write_your_website'); ?>
                                                                </b>
                                                    </label>
                                                </section>
                                                
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-home"></i>
                                                        <input type="text" name="address" class="required address" onblur="set_cart_map('iio');" value="<?php echo $row['address'];?>">
                                                        <b class="tooltip tooltip-right"><?php echo translate('address'); ?></b>
                                                    </label>
                                                </section>
                                                
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-home"></i>
                                                        <input type="text" name="trade_license" class="required" value="<?php echo $row['trade_license'];?>">
                                                        <b class="tooltip tooltip-right"><?php echo translate('trade_license'); ?></b>
                                                    </label>
                                                </section>

                        
                                                <section class="col-md-8">
                                                    <label for="file" class="input input-file">
                                                        <div class="button btn-u btn-u-cust">
                                                            <input type="file" name="image" 
                                                                onchange="document.getElementById('nam').value = this.value;">
                                                                    <?php echo translate('browse'); ?>
                                                        </div>
                                                        <input type="text" id="nam" placeholder="Change Profile Picture" readonly>
                                                    </label>
                                                </section>
                                              
                                                <section class="col-md-8" id="lnlat" style="display:none;">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-home"></i>   
                                                        <input id="langlat" type="text" placeholder="langitude - latitude" name="langlat" value="<?php echo $row['lat_lang']; ?>" class="form-control required" readonly>
                                                    </label>
                                                </section>

                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-home"></i>
                                                        <div class="" id="maps" style="height:400px;" >
                                                            <div id="map-canvas" style="height:400px;"></div>
                                                        </div>
                                                    </label>
                                                </section>

                                            </fieldset>
                                            <?php
												}
											?>
                                            <footer>
                                            	<section class="col-md-8">
                                                    <div class="pull-right">
                                                        <span type="submit" class="btn-u btn-u-update btn-block margin-bottom-20 btn-labeled fa fa-check-circle submitter" data-msg='Info Updated!' data-ing='Updating..'>
															<?php echo translate('update_info')?>
                                                        </span>
                                                    </div>
                                                </section>
                                            </footer>
                                        </form>         
                                        <!-- End Reg-Form -->
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab-3">
                               <div class="row margin-bottom-40">
                               		<div class="col-md-12">
										<?php
                                            echo form_open(base_url() . 'index.php/home/registration/reseller_update_password/', array(
                                                'class' => 'sky-form',
                                                'method' => 'post',
                                                'enctype' => 'multipart/form-data',
                                                'id' => 'sky-form1',
												'novalidate' => 'novalidate'
                                            ));
                                        ?> 
                                            <fieldset>                  
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-lock"></i>
                                                        <input type="password" name="password" placeholder="<?php echo translate('current_password');?>">
                                                        <b class="tooltip tooltip-bottom-right">
															<?php echo translate('enter_your_current_password');?>
                                                        		</b>
                                                    </label>
                                                </section>
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-key"></i>
                                                        <input type="password" name="password1" class="pass pass1" placeholder="<?php echo translate('new_password');?>">
                                                        <b class="tooltip tooltip-bottom-right">
															<?php echo translate('enter_your_new_password');?>
                                                        		</b>
                                                    </label>
                                                </section>
                                                
                                                <section class="col-md-8">
                                                    <label class="input">
                                                        <i class="icon-append fa fa-thumbs-up"></i>
                                                        <input type="password" name="password2" class="pass pass2" placeholder="<?php echo translate('confirm_new_password');?>">
                                                        <b class="tooltip tooltip-bottom-right">
															<?php echo translate('re-enter_your_new_password');?></b>
                                                        <div id="pass_note"></div>
                                                    </label>
                                                </section>
                                            </fieldset>
                                            <footer>
                                               <section class="col-md-8">
                                                    <div class="pull-right">
                                                          <span class="btn btn-u btn-u-update btn-block margin-bottom-20 btn-labeled fa fa-key submitter pass_chng disabled" disabled='disabled' data-msg='Password Saved!' data-ing='Saving'><?php echo translate('save_password'); ?></span>
                                                    </div>
                                               </section>
                                            </footer>
                                         </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Profile Body-->
            </div>
        </div><!--/end row-->
    </div><!--/container-->    
    <!--=== End Profile ===-->
<?php
    }
?>
<script>
	var mismatch = '<?php echo translate('password_mismatched'); ?>';
	var required = '<?php echo translate('required'); ?>';
	var must_number = '<?php echo translate('must_be_a_number'); ?>';
	var valid_email = '<?php echo translate('must_be_a_valid_email_address'); ?>';
	var incor = '<?php echo translate('incorrect_password'); ?>';
	var base_url = '<?php echo base_url(); ?>';
</script>
<script src="<?php echo base_url(); ?>template/front/assets/js/custom/profile.js"></script>
<script>
    
    $(document).ready(function(){
        set_cart_map();
    });

    function set_cart_map(tty){
        //$('#maps').animate({ height: '400px' }, 'easeInOutCubic', function(){});
        initialize();
        var address = [];
        //$('#pos').show('fast');
        //$('#lnlat').show('fast');
        $('.address').each(function(index, value){
            if(this.value !== ''){
                address.push(this.value);
            }
        });
        address = address.toString();
        deleteMarkers();
        geocoder.geocode( { 'address': address}, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if($('#langlat').val().indexOf(',')  == -1 || $('#first').val() == 'no' || tty == 'iio'){
                    deleteMarkers();
                    var location = results[0].geometry.location; 
                    var marker = addMarker(location);
                    map.setCenter(location);
                    $('#langlat').val(location);
                } else if($('#langlat').val().indexOf(',')  >= 0){
                    deleteMarkers();
                    var loca = $('#langlat').val();
                    loca = loca.split(',');
                    var lat = loca[0].replace('(','');
                    var lon = loca[1].replace(')','');
                    var marker = addMarker(new google.maps.LatLng(lat, lon));
                    map.setCenter(new google.maps.LatLng(lat, lon));
                }
                if($('#first').val() == 'yes'){
                    $('#first').val('no');
                }
                // Add dragging event listeners.
                google.maps.event.addListener(marker, 'drag', function() {
                    $('#langlat').val(marker.getPosition());
                });
            }
        }); 
    }

        var geocoder;
        var map;
        var markers = [];
        function initialize() {
            geocoder = new google.maps.Geocoder();
            var latlng = new google.maps.LatLng(-34.397, 150.644);
            var mapOptions = {
                zoom: 14,
                center: latlng
            }
            map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
            google.maps.event.addListener(map, 'click', function(event) {
                deleteMarkers();
                var marker = addMarker(event.latLng);
                $('#langlat').val(event.latLng);    
                // Add dragging event listeners.
                google.maps.event.addListener(marker, 'drag', function() {
                    $('#langlat').val(marker.getPosition());
                });
                
            });     
        }
        

    /*
        var address = [];
        $('#maps').show('fast');
        $('#pos').show('fast');
        $('#lnlat').show('fast');
        $(".address").each(
        address.push(this.value);
        );
    */

        $('.address').on('blur', function(){
            set_cart_map();
        });

        // Add a marker to the map and push to the array.
        function addMarker(location) {
            var image = {
                url: base_url+'uploads/others/marker.png',
                size: new google.maps.Size(40, 60),
                origin: new google.maps.Point(0,0),
                anchor: new google.maps.Point(20, 62)
            };

            var shape = {
                coords: [1, 5, 15, 62, 62, 62, 15 , 5, 1],
                type: 'poly'
            };

            var marker = new google.maps.Marker({
                position: location,
                map: map,
                draggable:true,
                icon: image,
                shape: shape,
                animation: google.maps.Animation.DROP
            });
            markers.push(marker);
            return marker;
        }

        // Deletes all markers in the array by removing references to them.
        function deleteMarkers() {
            clearMarkers();
            markers = [];
        }

        // Sets the map on all markers in the array.
        function setAllMap(map) {
            for (var i = 0; i < markers.length; i++) {
                markers[i].setMap(map);
            }
        }

        // Removes the markers from the map, but keeps them in the array.
        function clearMarkers() {
            setAllMap(null);
        }
        //google.maps.event.addDomListener(window, 'load', initialize);
</script>
