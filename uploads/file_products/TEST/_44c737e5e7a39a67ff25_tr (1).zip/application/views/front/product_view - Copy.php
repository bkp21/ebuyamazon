<?php
    foreach($product_data as $row)
    {
?>
<script src="http://www.google.com/jsapi"></script>
<script type="text/javascript" src="http://google-maps-utility-library-v3.googlecode.com/svn/tags/markerclusterer/1.0/src/markerclusterer.js"></script>
<div class="shop-product">
    <div class="container product_head">
        <div class="col-md-6">
            <ul class="breadcrumb-v5">
                <li><a href="<?php echo base_url(); ?>index.php/home/"><i class="fa fa-home"></i></a></li>
                <li><a href="<?php echo base_url(); ?>index.php/home/category/"><?php echo translate('products');?></a></li>
                <li>
                    <a href="<?php echo base_url(); ?>index.php/home/category/<?php echo $row['category']; ?>">
                        <?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?>	 
                    </a>
                </li>
                <li class="active">
                    <a href="<?php echo base_url(); ?>index.php/home/category/<?php echo $row['category']; ?>/<?php echo $row['sub_category']; ?>">
                        <?php echo $this->crud_model->get_type_name_by_id('sub_category',$row['sub_category'],'sub_category_name'); ?>
                    </a>
                </li>
            </ul>
        </div>
        <div class="col-md-6" style="padding-top:10px;">
            <div id="share"></div>
        </div>
    </div>
    
    <div class="container">
        <div class="row margin-bottom-20">
            <div class="row">
        		<!--PRODUCT IMAGE START---------------------------------->
            	<div class="col-md-4">
                <div class="ms-showcase2-template">
                    <div id="slider" class="flexslider" style="overflow:hidden;">
                    <?php
                        $thumbs = $this->crud_model->file_view('product',$row['product_id'],'','','thumb','src','multi','all');
                        $mains = $this->crud_model->file_view('product',$row['product_id'],'','','no','src','multi','all');
                    ?>
                      <ul class="slides" >
                        <?php 
							//var_dump($mains);
                            foreach ($mains as $row1) {
                        ?>
                            <li class="zoom">
                              <img src="<?php echo $row1; ?>" class="img-responsive zoom" />
                            </li>
                        <?php 
                            }
                         ?>
                        <!-- items mirrored twice, total of 12 -->
                      </ul>
                    </div>
                    <span id="zom" class="btn-u btn-u-xs btn-u-cust">
                        <i class="fa fa-search-plus"></i> <?php echo translate('preview');?>
                    </span>
                    <?php
                        if(count($mains) > 1){
                    ?>
                    <div id="carousel" class="flexslider" style="overflow:hidden;">
                      <ul class="slides" >
                        <?php
                            $i = 0;
                            foreach ($thumbs as $row1) {
                        ?>
                            <li style="border:4px solid #fff;">
                             <a class="fancybox-button zoomer" data-rel="fancybox-button" title="<?php echo $row['title'].' ('.($i+1).')'; ?>" href="<?php echo $mains[$i]; ?>" ></a>
                              <img src="<?php echo $row1; ?>" />
                            </li>
                        <?php
                            $i++;
                            }
                         ?>
                      </ul>
                    </div>
                    <script>
                        $( "#zom" ).click(function() {
                            $('.flex-active-slide').find('a').click();
                        });
                    </script>
                    <?php
                        } else if(count($mains) == 1) {
                    ?>
                        <a class="fancybox-button zoomer fancyier" data-rel="fancybox-button" title="<?php echo $row['title']; ?>" href="<?php echo $mains[0]; ?>" ></a>
                        <script>
                            $( "#zom" ).click(function() {
                                $('.fancyier').click();
                            });
                        </script>
                    <?php
                        }
                    ?>
                </div>
            </div>
    		<!--PRODUCT IMAGE END--------------------------------------->
            
            <!--MAIN PERAMETERS START---------------------------------->
            <?php /*?><div class="col-md-8">
                <div class="shop-product-heading">
                    <h2><?php echo $row['title']; ?></h2>
                </div><!--/end shop product social-->
                <div class="row margin-bottom-30">
                    <?php
                        $i = 0;
                        $params = $this->crud_model->get_mains($row['product_id']);
                        foreach($params as $row1){
                            if(!empty($row1)){
                                $i++;
                                if($i <= 6){
                    ?>
                    <div class="col-md-3 product-service md-margin-bottom-30">
                        <div class="product-service-heading">
                            <h3 style="color:#fff; text-transform:uppercase;"><?php echo $row1['name'];?></h3>
                        </div>
                        <div class="product-service-in">
                            <h3><?php echo $row1['value']; ?></h3>
                        </div>
                    </div>
                    <?php
                                if($i % 4 == 0) {
                    ?>
                    </div>
                    <div class="row margin-bottom-30">
                    <?php
                                    }
                                }
                            }
                        }
                    ?>
                </div> 
                
                
                <div class="col-md-12" style="background:#F1F1F1; border:1px solid #E8E8E8; padding:5px 0px; alignment-adjust:central;">
                    <?php   
                        if($this->session->userdata('reseller_login') == 'yes' && $row['file'] !== ''){
                            if('' =='') {
                    ?>
                        <div class="col-md-4 col-sm-12">
                            <a data-toggle="modal" data-target="#pdfs" class="point">
                                <div class="btn-u btn-u-blue btn-block btn-labeled fa fa-file-text">
                                    <?php echo translate('reseller(.pdf)');?> 
                                </div>
                            </a>
                        </div>
                    <?php
                            }
                        }
                    ?>
                    <div class="col-md-4 col-sm-12">
                        <a data-toggle="modal" data-target="#resellers_list" class="point">
                            <div class="btn-u btn-u-update btn-block btn-labeled fa fa-certificate">
                                <?php echo translate('resellers');?>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <a data-toggle="modal" data-target="#video" class="point">
                            <div class="btn-u btn-u-cust btn-block btn-labeled fa fa-video-camera">
                                <?php echo translate('vedio');?>
                            </div>
                        </a>
                    </div>
                </div>   
            </div><?php */?>
        
            	<!--MAIN PERAMETERS END------------------------------------>
                
                <div class="col-md-8">
                    <div class="bg-main_p">
                    <div class="shop-product-heading">
                        <h2><?php echo $row['title']; ?></h2>
                    </div><!--/end shop product social-->
                        <div class="row margin-bottom-30">
                            <?php
                                $i = 0;
                                $params = $this->crud_model->get_mains($row['product_id']);
                                foreach($params as $row1){
                                    if(!empty($row1)){
                                        $i++;
                                        if($i <= 6){
                            ?>
                            <div class="col-md-3 md-margin-bottom-30" style="border-right:1px solid #fff;">
                                <div class="product-service-heading">
                                    <h3 style="color:#fff; text-transform:uppercase;"><?php echo $row1['name'];?></h3>
                                </div>
                                <div class="">
                                    <h3><?php echo $row1['value']; ?></h3>
                                </div>
                            </div>
                            <?php
                                        if($i % 4 == 0) {
                            ?>
                            </div>
                        <div class="row margin-bottom-30">
                        <?php
                                        }
                                    }
                                }
                            }
                        ?>
                    </div>
                    
                    
                    <div class="col-md-12" style="background:#F1F1F1; border:1px solid #E8E8E8; padding:5px 0px; alignment-adjust:central;margin-top:30px;">
                        <?php   
                            if($this->session->userdata('reseller_login') == 'yes' && $row['file'] !== ''){
                                if('' =='') {
                        ?>
                            <div class="col-md-4 col-sm-12">
                                <a data-toggle="modal" data-target="#pdfs" class="point">
                                    <div class="btn-u btn-u-blue btn-block btn-labeled fa fa-file-text">
                                        <?php echo translate('reseller(.pdf)');?> 
                                    </div>
                                </a>
                            </div>
                        <?php
                                }
                            }
                        ?>
                        <div class="col-md-4 col-sm-12">
                            <a data-toggle="modal" data-target="#resellers_list" class="point">
                                <div class="btn-u btn-u-update btn-block btn-labeled fa fa-certificate">
                                    <?php echo translate('resellers');?>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <a data-toggle="modal" data-target="#video" class="point">
                                <div class="btn-u btn-u-cust btn-block btn-labeled fa fa-video-camera">
                                    <?php echo translate('vedio');?>
                                </div>
                            </a>
                        </div>
                    </div>                     
                    </div><br><br>
                </div>
            </div>
       </div><!--/end row-->
       
       
        <div class="row">
            <div class="row">
                <div class="col-md-9">
                    <div class="panel panel-dark-blue">
                        <div class="panel-heading">
                            <h3 class="panel-title heading heading-v4">
                            <?php echo translate('detail_specifications');?>
                            </h3>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <?php if($row['brand'] !='') { ?>
                                <tr>
                                    <td style="text-align:center;"><?php echo translate('brand');?></td>
                                    <td style="text-align:left;"><?php echo $this->db->get_where('brand',array('brand_id'=>$row['brand']))->row()->name; ?></td>
                                </tr>
                                <?php } if($row['sale_price'] !='') { ?>
                                 <tr>
                                    <td style="text-align:center;"><?php echo translate('price');?></td>
                                    <td style="text-align:left;"><?php echo $row['sale_price']; ?></td>
                                </tr>
                                <?php } ?>
                                
                                <?php 
                                    $ai = json_decode($row['category_fields'],true);
                                    if(count($ai)>0){
                                        foreach ($ai as $val) {
                                            if($val['value'] !== ''){
                                ?>
                                 <tr>
                                    <td style="text-align:center;"><?php echo $val['name']; ?></td>
                                    <td style="text-align:left;"><?php echo $val['value']; ?></td>
                                </tr>
                                <?php 
                                            }
                                        }
                                    }
                                ?>
                                
                                <?php 
                                    $ai = json_decode($row['additional_fields'],true);
                                    if(count($ai)>0){
                                        foreach ($ai as $val) {
                                            if($val['value'] !== ''){
                                ?>
                                 <tr>
                                    <td style="text-align:center;"><?php echo $val['name']; ?></td>
                                    <td style="text-align:left;"><?php echo $val['value']; ?></td>
                                </tr>
                                <?php 
                                            }
                                        }
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="sdbar posts margin-bottom-20">
                        <h4 class="text_color center_text mr_top_0"><?php echo translate('similar_products'); ?></h4>
                        <?php
                            $i = 0;
                            $this->db->where('sub_category',$row['sub_category']);
                            $this->db->limit(5);
                            $this->db->order_by('product_id','desc');
                            $a = $this->db->get('product')->result_array();
                            foreach ($a as $row2) {
                            $now = $this->db->get_where('product',array('product_id'=>$row2['product_id']))->row();             
                        ?>
                        <dl class="dl-horizontal">
                            <dt>
                                <a href="<?php echo $this->crud_model->product_link($now->product_id); ?>">
                                    <img src="<?php echo $this->crud_model->file_view('product',$now->product_id,'','','thumb','src','multi','one'); ?>" alt="" />
                                </a>
                            </dt>
                            <dd>
                                <p>
                                    <a href="<?php echo $this->crud_model->product_link($now->product_id); ?>">
                                        <?php echo $now->title; ?>
                                    </a>
                                </p>
                                <p>
                                <?php if($this->crud_model->get_type_name_by_id('product',$now->product_id,'discount') > 0){ ?>
                                    <span>
                                        <?php echo currency().$this->crud_model->get_product_price($now->product_id); ?>
                                    </span>
                                    <span style=" text-decoration: line-through;color:#c9253c;">
                                        <?php echo currency().$now->sale_price; ?>
                                    </span>
                                <?php } else { ?>
                                    <span>
                                        <?php echo currency().$now->sale_price; ?>
                                    </span>
                                <?php } ?>
                                </p>
                            </dd>
                        </dl>
                        <?php	
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="resellers_list" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-hidden="true" data-dismiss="modal" id="v_close_logup_modal" class="close" type="button">×</button>
                <br>
            </div>
            <div class="modal-body">
                <div class="panel panel-dark-blue">
                    <div class="panel-heading">
                        <h3 class="panel-title heading heading-v4">
                        <?php echo translate('Resellers_of_this_product');?>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <div class="map-container">
                            <div id="map" class="mapping"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button data-dismiss="modal" class="btn-u btn-u-default" type="button" id="v_clsreg" ><?php echo translate('close');?></button>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="video" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-hidden="true" data-dismiss="modal" id="v_close_logup_modal" class="close" type="button">×</button>
                <br>
            </div>
            <div class="modal-body video-container">
                <?php echo $row['video']; ?>
            </div>
            <div class="modal-footer">
                <button data-dismiss="modal" class="btn-u btn-u-default" type="button" id="v_clsreg" ><?php echo translate('close');?></button>
            </div>
        </div>
    </div>
</div>

<!-- End Modal -->
<!-- Modal -->
<div class="modal fade" id="pdfs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-hidden="true" data-dismiss="modal" id="v_close_logup_modal" class="close" type="button">×</button>
                <br>
            </div>
            <div class="modal-body">
                <iframe src="http://docs.google.com/gview?url=<?php echo base_url(); ?>uploads/reseller_file/<?php echo $row['file']; ?>&embedded=true" style="width:100%; height:400px;" frameborder="0"></iframe>
            </div>
            <div class="modal-footer">
                <a href="<?php echo base_url(); ?>uploads/reseller_file/<?php echo $row['file']; ?>" target="_blank" class="btn-u btn-u-default" ><?php echo translate('download');?></a>
                <button data-dismiss="modal" class="btn-u btn-u-default" type="button" id="v_clsreg" ><?php echo translate('close');?></button>
            </div>
        </div>
    </div>
</div>
<!-- End Modal -->


<?php
    $resellers = json_decode($row['resellers'],true);
    }
?>

<script>
    var sale_details = [
    <?php
	if(!empty($resellers)){
        foreach($resellers as $row){
            $info = $this->db->get_where('reseller',array('reseller_id'=>$row))->row();
            $address    = $info->address;
            $langlat    = explode(',',str_replace('(','',str_replace(')','',$info->lat_lang)));
            $reseller_name = $info->reseller_name;
    ?>
        ['<?php echo $address; ?>', <?php echo $langlat[0]; ?>, <?php echo $langlat[1]; ?>, '<?php echo $reseller_name; ?>'],
    <?php 
        }
	}
    ?>
    ];

    google.load('maps', '3', {
        other_params: 'sensor=false'
    });
    
    google.setOnLoadCallback(initialize);
    
    var styles = [
        [{
            url: '../images/conv30.png',
            height: 27,
            width: 30,
            anchor: [3, 0],
            textColor: '#ff00ff',
            opt_textSize: 10
        }, {
            url: '../images/conv40.png',
            height: 36,
            width: 40,
            opt_anchor: [6, 0],
            opt_textColor: '#ff0000',
            opt_textSize: 11
        }, {
            url: '../images/conv50.png',
            width: 50,
            height: 45,
            opt_anchor: [8, 0],
            opt_textSize: 12
        }],
        [{
            url: '../images/heart30.png',
            height: 26,
            width: 30,
            opt_anchor: [4, 0],
            opt_textColor: '#ff00ff',
            opt_textSize: 10
        }, {
            url: '../images/heart40.png',
            height: 35,
            width: 40,
            opt_anchor: [8, 0],
            opt_textColor: '#ff0000',
            opt_textSize: 11
        }, {
            url: '../images/heart50.png',
            width: 50,
            height: 44,
            opt_anchor: [12, 0],
            opt_textSize: 12
        }]
    ];
    
    var markerClusterer = null;
    var map = null;
    var imageUrl = 'http://chart.apis.google.com/chart?cht=mm&chs=24x32&' +
        'chco=FFFFFF,008CFF,000000&ext=.png';
    
    $('#resellers_list').on('shown.bs.modal', function (e) {
        initialize();
    })

    function refreshMap() {
        //if (markerClusterer) {
        //  markerClusterer.clearMarkers();
        //}
    
        var markers = [];
        var infoWindows = [];
    
        var markerImage = new google.maps.MarkerImage(imageUrl,
            new google.maps.Size(24, 32));
    
    
        var bound = new google.maps.LatLngBounds();
        // Loop through our array of markers & place each one on the map  
        for (i = 0; i < sale_details.length; i++) {
            var latLng = new google.maps.LatLng(sale_details[i][1], sale_details[i][2])
            var marker = new google.maps.Marker({
                position: latLng,
                draggable: false,
                icon: markerImage,
                animation: google.maps.Animation.DROP,
                infoWindowIndex: i
            });
    
            bound.extend(new google.maps.LatLng(sale_details[i][1], sale_details[i][2]));
    
            var content = '<div class="info_content">' +
                '<h3>' + sale_details[i][0] + '</h3>' +
                '<p>' + sale_details[i][3] + '</p>' +
                '</div>';
    
            var infoWindow = new google.maps.InfoWindow({
                content: content
            });
    
            google.maps.event.addListener(marker, 'click',
                function(event) {
                    infoWindows[this.infoWindowIndex].open(map, this);
                }
            );
    
            infoWindows.push(infoWindow);
            markers.push(marker);
        }
    
    
        var zoom = parseInt(16);
        var size = parseInt(40);
        var style = parseInt(-1);
    
        markerClusterer = new MarkerClusterer(map, markers, {
            maxZoom: zoom,
            gridSize: size,
            styles: styles[style]
        });
    
        //map.setCenter(bound.getCenter())
        //map1.setCenter(bound1.getCenter())
        map.fitBounds(bound);
    }
    
    function initialize() {
        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 4,
            center: new google.maps.LatLng(23.91, 90.38),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
    
        refreshMap();
    }
    
    function clearClusters(e) {
        e.preventDefault();
        e.stopPropagation();
        markerClusterer.clearMarkers();
    }

	$(document).ready(function() {
		$('#share').share({
			networks: ['facebook','googleplus','twitter','linkedin','tumblr','in1','stumbleupon','digg'],
			theme: 'square'
		});
	});
	
	$(window).load(function() {
	<?php
		if(count($mains) > 1){
	?>
	  $('#carousel').flexslider({
		animation: "slide",
		controlNav: false,
		animationLoop: false,
		slideshow: false,
		itemWidth: 100,
		itemMargin: 5,
		asNavFor: '#slider'
	  });
	<?php
		}
	?>
	 
	  $('#slider').flexslider({
		animation: "slide",
		controlNav: false,
		animationLoop: false,
		slideshow: false,
		sync: "#carousel"
	  });
	});

	$(function(){
		$('.zoom').zoome({hoverEf:'transparent',showZoomState:true,magnifierSize:[200,200]});
	});
	
	function destroyZoome(obj){
		if(obj.parent().hasClass('zm-wrap'))
		{
			obj.unwrap().next().remove();
		}
	}
	
</script>
<style>
      #map-container {
        padding: 6px;
        border-width: 1px;
        border-style: solid;
        border-color: #ccc #ccc #999 #ccc;
        -webkit-box-shadow: rgba(64, 64, 64, 0.5) 0 2px 5px;
        -moz-box-shadow: rgba(64, 64, 64, 0.5) 0 2px 5px;
        box-shadow: rgba(64, 64, 64, 0.1) 0 2px 5px;
        width: 100%;
      }
      #map {
        width: 100%;
        height: 400px;
      }
      #map1 {
        width: 100%;
        height: 400px;
      }
      #actions {
        list-style: none;
        padding: 0;
      }
      #inline-actions {
        padding-top: 10px;
      }
      .item {
        margin-left: 20px;
      }
	  	.video-container {
			position:relative;
			padding-bottom:56.25%;
			padding-top:30px;
			height:0;
			overflow:hidden;
		}
		
		.video-container iframe, .video-container object, .video-container embed {
			position:absolute;
			top:0;
			left:0;
			width:100%;
			height:100%;
		}
</style>