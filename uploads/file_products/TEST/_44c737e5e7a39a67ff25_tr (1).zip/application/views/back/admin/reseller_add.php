<div>
    <?php
		echo form_open(base_url() . 'index.php/admin/reseller/do_add/', array(
			'class' => 'form-horizontal',
			'method' => 'post',
			'id' => 'reseller_add',
			'enctype' => 'multipart/form-data'
		));
	?>
        <div class="panel-body">
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('company_name');?>
                        </label>
                <div class="col-sm-6">
                    <input type="text" name="reseller_name" id="demo-hor-1" 
                        class="form-control required" placeholder="<?php echo translate('company_name');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('proprietor_name');?>
                        </label>
                <div class="col-sm-6">
                    <input type="text" name="proprietor" id="demo-hor-1" 
                        class="form-control required" placeholder="<?php echo translate('proprietor_name');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('email');?>
                        </label>
                <div class="col-sm-6">
                    <input type="email" name="email" id="demo-hor-1" 
                        class="form-control required" placeholder="<?php echo translate('email');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('password');?>
                        </label>
                <div class="col-sm-6">
                    <input type="password" name="password" id="demo-hor-1" 
                        class="form-control required" placeholder="<?php echo translate('password');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('address');?>
                        </label>
                <div class="col-sm-6">
                    <textarea name="address" rows='5' class="form-control"></textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('phone_number');?>
                        </label>
                <div class="col-sm-6">
                    <input type="text" name="phone" id="demo-hor-1" 
                        class="form-control" placeholder="<?php echo translate('phone_number');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('mobile_number');?>
                        </label>
                <div class="col-sm-6">
                    <input type="text" name="mobile" id="demo-hor-1" 
                        class="form-control required" placeholder="<?php echo translate('mobile_number');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('website');?>
                        </label>
                <div class="col-sm-6">
                    <input type="text" name="web" id="demo-hor-1" 
                        class="form-control required" placeholder="<?php echo translate('website');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1">
                    <?php echo translate('trade_license_no');?>
                        </label>
                <div class="col-sm-6">
                    <input type="text" name="trade_license" id="demo-hor-1" 
                        class="form-control required" placeholder="<?php echo translate('trade_license_no');?>" >
                </div>
            </div>
            
            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-2"><?php echo translate('reseller_logo');?></label>
                <div class="col-sm-6">
                    <span class="pull-left btn btn-default btn-file">
                        <?php echo translate('select_brand_logo');?>
                        <input type="file" name="img" id='imgInp' accept="image">
                    </span>
                    <br><br>
                    <span id='wrap' class="pull-left" >
                        <img src="<?php echo base_url(); ?>uploads/others/photo_default.png" 
                        	width="48.5%" id='blah' > 
                    </span>
                </div>
            </div>

        </div>
        
    
        <div class="panel-footer">
            <div class="row">
            	<div class="col-md-11">
                    <span class="btn btn-purple btn-labeled fa fa-refresh pro_list_btn pull-right" 
                        onclick="ajax_set_full('add','<?php echo translate('add_reseller'); ?>','<?php echo translate('successfully_added!'); ?>','reseller_add',''); "><?php echo translate('reset');?>
                    </span>
                </div>
                
                <div class="col-md-1">
                    <span class="btn btn-success btn-md btn-labeled fa fa-upload pull-right" onclick="form_submit('reseller_add','<?php echo translate('reseller_has_been_uploaded!'); ?>');proceed('to_add');" ><?php echo translate('upload');?></span>
                </div>
                
            </div>
        </div>
	</form>
</div>

<script src="<?php echo base_url(); ?>template/back/js/custom/brand_form.js"></script>
<script>
	$(document).ready(function() {
		$("form").submit(function(e){
			return false;
		});
	});
</script>