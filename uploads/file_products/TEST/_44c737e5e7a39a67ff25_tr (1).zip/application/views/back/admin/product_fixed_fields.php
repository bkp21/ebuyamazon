<?php
    if(!empty($all_af)){
        foreach($all_af as $row1){
?> 
    <div class="form-group btm_border">
        <label class="col-sm-2 control-label" for="demo-hor-4"><?php echo translate($row1['name']); ?></label>
        <div class="col-sm-4">
            <input type="text" name="field_<?php echo $row1['no']; ?>" id="demo-hor-5" placeholder="<?php echo translate($row1['name']); ?>" class="form-control">
        </div>
        <div class="col-sm-2">
            <input class="main_param" data-ty="main" value="ok" name="main_<?php echo $row1['no']; ?>" <?php if($row1['main'] == 'ok'){echo 'checked';} ?>  type="checkbox" />
            <span class="main_param_state"></span>
            <?php if($row1['main'] !== 'ok'){ ?>
            <input value="0" name="main_<?php echo $row1['no']; ?>" class="temo_inp"  type="hidden" />
            <?php } ?>
        </div>
        <div class="col-sm-2">
            <input class="main_param" data-ty="short" value="ok" <?php if($row1['short'] == 'ok'){echo 'checked';} ?> name="short_<?php echo $row1['no']; ?>"  type="checkbox" />
            <span class="main_param_state"></span>
            <?php if($row1['short'] !== 'ok'){ ?>
            <input value="0" name="short_<?php echo $row1['no']; ?>" class="temo_inp"  type="hidden" />
            <?php } ?>
        </div>
    </div>
<?php
        }
    }
?> 