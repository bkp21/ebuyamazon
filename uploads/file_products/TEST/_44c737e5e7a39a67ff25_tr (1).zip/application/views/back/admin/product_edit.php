<?php
    foreach($product_data as $row){
?>
<div class="row">
    <div class="col-md-12">
        <?php
			echo form_open(base_url() . 'index.php/admin/product/update/' . $row['product_id'], array(
				'class' => 'form-horizontal',
				'method' => 'post',
				'id' => 'product_edit',
				'enctype' => 'multipart/form-data'
			));
		?>
            <div class="panel-body">
                    
                <div class="tab-base">
        
        
                    <!--Tabs Content-->                    
                    <div class="tab-content">
                        
                        <div id="product_details" class="tab-pane fade active in">
        
                            <div class="form-group btm_border">
                                <h4 class="text-thin text-center"><?php echo translate('product_details'); ?></h4>                            
                            </div>

                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-1"><?php echo translate('product_title');?></label>
                                <div class="col-sm-8">
                                    <input type="text" name="title" id="demo-hor-1" placeholder="<?php echo translate('product_title');?>" value="<?php echo $row['title']; ?>" class="form-control required">
                                </div>
                            </div>
                            
                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-2"><?php echo translate('category');?></label>
                                <div class="col-sm-8">
                                    <?php echo $this->crud_model->select_html('category','category','category_name','edit','demo-chosen-select required',$row['category'],'','','get_cat'); ?>
                                </div>
                            </div>
                            
                            <div class="form-group btm_border" id="brn" >
                                <label class="col-sm-2 control-label" for="demo-hor-4"><?php echo translate('brand');?></label>
                                <div class="col-sm-8" id="brand">
                                	<?php echo $this->crud_model->select_html('brand','brand','name','edit','demo-chosen-select',$row['brand'],'category',$row['category'],'','jsoned'); ?>
                                </div>
                            </div>                            
                                            
                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-11"><?php echo translate('tags');?></label>
                                <div class="col-sm-8">
                                    <input type="text" name="tag" data-role="tagsinput" value="<?php echo $row['tag']; ?>" placeholder="<?php echo translate('tags');?>" class="form-control">
                                </div>
                            </div>
                            
                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-12"><?php echo translate('images');?></label>
                                <div class="col-sm-6">
                                    <span class="pull-left btn btn-default btn-file"> <?php echo translate('choose_file');?>
                                        <input type="file" multiple name="images[]" onchange="preview(this);" id="demo-hor-inputpass" class="form-control">
                                    </span>
                                    <br><br>
                                    <span id="previewImg" ></span>
                                </div>
                            </div>

                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-13"></label>
                                <div class="col-sm-6">
                                    <?php 
                                        $images = $this->crud_model->file_view('product',$row['product_id'],'','','thumb','src','multi','all');
                                        if($images){
                                            foreach ($images as $row1){
                                                $a = explode('.', $row1);
                                                $a = $a[(count($a)-2)];
                                                $a = explode('_', $a);
                                                $p = $a[(count($a)-2)];
                                                $i = $a[(count($a)-3)];
                                    ?>
                                        <div class="delete-div-wrap">
                                            <span class="close">&times;</span>
                                            <div class="inner-div">
                                                <img class="img-responsive" width="100" src="<?php echo $row1; ?>" data-id="<?php echo $i.'_'.$p; ?>" alt="User_Image" >
                                            </div>
                                        </div>
                                    <?php 
                                            }
                                        } 
                                    ?>
                                </div>
                            </div>

                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-5"><?php echo translate("pdf_for_resellers");?></label>
                                <div class="col-sm-8">
                                <span class="pull-left btn btn-default btn-file"> <?php echo translate('choose_file');?>
                                    <input type="file" name="pdf" id="demo-hor-12" class="form-control">
                                    </span>
                                </div>
                            </div>

                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-5"><?php echo translate("video(Youtube_link)");?></label>
                                <div class="col-sm-8">
                                    <input type="text" name="video" id="demo-hor-5" placeholder="<?php echo translate("Youtube_link");?>" value="<?php echo $this->crud_model->vid_iframe($row['video'],'itv'); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-5"><?php echo translate("price_(MRP)");?></label>
                                <div class="col-sm-4">
                                    <input type="number" name="sale_price" value="<?php echo $row['sale_price']; ?>" id="demo-hor-5" placeholder="<?php echo translate("price_(MRP)");?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-5"><?php echo translate("price_(DP)");?></label>
                                <div class="col-sm-4">
                                    <input type="number" value="<?php echo $row['purchase_price']; ?>" name="purchase_price" id="demo-hor-5" placeholder="<?php echo translate("price_(DP)");?>" class="form-control">
                                </div>
                            </div>
                            
                            
                            <div id="fixed_additional_fields">
                            	<?php
                                    $ai = json_decode($row['category_fields'],true);
                                    $cai = json_decode($this->db->get_where('category',array('category_id'=>$row['category']))->row()->fields,true);
                                    foreach($cai as $ro){
                                        $value = '';
                                        $main = '0';
                                        $short = '0';
                                        foreach ($ai as $ra) {
                                            if($ro['no'] == $ra['no']){
                                                $value = $ra['value'];
                                                $main = $ra['main'];
                                                $short = $ra['short'];
                                            }
                                        }
								?>
                                    <div class="form-group btm_border">
                                        <label class="col-sm-2 control-label" for="demo-hor-4"><?php echo translate($ro['name']); ?></label>
                                        <div class="col-sm-4">
                                            <input type="text" name="field_<?php echo $ro['no']; ?>" value="<?php echo $value; ?>" id="demo-hor-5" placeholder="<?php echo translate($ro['name']); ?>" class="form-control">
                                        </div>
                                        <div class="col-sm-2">
                                            <input class="main_param" data-ty="main" value="ok" name="main_<?php echo $ro['no']; ?>" <?php if($main == 'ok'){echo 'checked';} ?>  type="checkbox" />
                                            <span class="main_param_state"></span>
                                            <?php if($main !== 'ok'){ ?>
                                            <input value="0" name="main_<?php echo $ro['no']; ?>" class="temo_inp"  type="hidden" />
                                            <?php } ?>
                                        </div>
                                        <div class="col-sm-2">
                                            <input class="main_param" data-ty="short" value="ok" <?php if($short == 'ok'){echo 'checked';} ?> name="short_<?php echo $ro['no']; ?>"  type="checkbox" />
                                            <span class="main_param_state"></span>
                                            <?php if($short !== 'ok'){ ?>
                                            <input value="0" name="short_<?php echo $ro['no']; ?>" class="temo_inp"  type="hidden" />
                                            <?php } ?>
                                        </div>
                                    </div>
                            	<?php
									}
								?>
                            </div>
                            <div id="more_additional_fields">
                            	<?php
                                    $ai = json_decode($row['additional_fields'],true);
                                	foreach($ai as $ro){
								?>
                                    <div class="form-group">
                                        <div class="col-sm-2">
                                            <input type="text" name="ad_field_names[]" value="<?php echo $ro['name']; ?>" class="form-control"  placeholder="<?php echo translate('field_name'); ?>">
                                        </div>
                                        <div class="col-sm-4">
                                            <textarea rows="9"  class="summernotes" data-height="100" data-name="ad_field_values[]"><?php echo $ro['value']; ?></textarea>
                                        </div>
                                        <div class="col-sm-2">
                                            <input class="main_param" data-ty="main" value="ok" name="main_param_additional[]" <?php if($ro['main'] == 'ok'){ echo 'checked'; } ?>  type="checkbox" />
                                            <span class="main_param_state"></span>
                                            <?php if($ro['main'] !== 'ok'){ ?>
                                            <input value="0" name="main_param_additional[]" class="temo_inp"  type="hidden" />
                                            <?php } ?>
                                        </div>
                                        <div class="col-sm-2">
                                            <input class="main_param" data-ty="short" value="ok" name="short_additional[]" <?php if($ro['short'] == 'ok'){ echo 'checked'; } ?>  type="checkbox" />
                                            <span class="main_param_state"></span>
                                            <?php if($ro['short'] !== 'ok'){ ?>
                                            <input value="0" name="short_additional[]" class="temo_inp"  type="hidden" />
                                            <?php } ?>
                                        </div>
                                        <div class="col-sm-1">
                                            <span class="remove_it_v rmc btn btn-danger btn-icon icon-lg fa fa-trash" ></span>
                                        </div>
                                    </div>
                            	<?php
									}
								?>                            	
                            </div>
                            <div class="form-group btm_border">
                                <label class="col-sm-2 control-label" for="demo-hor-inputpass"></label>
                                <div class="col-sm-6">
                                    <div id="more_btn" class="btn btn-mint btn-labeled fa fa-plus pull-right">
                                    <?php echo translate('add_more_fields');?></div>
                                </div>
                            </div>
                            

                        </div>
                    </div>
                </div>
        
            </div>
    
            <div class="panel-footer">
                <div class="row">
                	<div class="col-md-11">
                    	<span class="btn btn-purple btn-labeled fa fa-refresh pro_list_btn pull-right" 
                            onclick="ajax_set_full('edit','<?php echo translate('edit_product'); ?>','<?php echo translate('successfully_edited!'); ?>','product_edit','<?php echo $row['product_id']; ?>') "><?php echo translate('reset');?>
                        </span>
                    </div>
                    
                    <div class="col-md-1">
                     	<span class="btn btn-success btn-md btn-labeled fa fa-wrench pull-right" onclick="form_submit('product_edit','<?php echo translate('successfully_edited!'); ?>');proceed('to_add');" ><?php echo translate('edit');?></span>
                    </div>
                    
                </div>
            </div>
    
        </form>
    </div>
</div>

<script src="<?php echo base_url(); ?>template/back/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js">
</script>

<input type="hidden" id="option_count" value="-1">

<script>
    window.preview = function (input) {
        if (input.files && input.files[0]) {
            $("#previewImg").html('');
            $(input.files).each(function () {
                var reader = new FileReader();
                reader.readAsDataURL(this);
                reader.onload = function (e) {
                    $("#previewImg").append("<div style='float:left;border:4px solid #303641;padding:5px;margin:5px;'><img height='80' src='" + e.target.result + "'></div>");
                }
            });
        }
    }

    function other_forms(){}
	
	function set_summer(){
        $('.summernotes').each(function() {
            var now = $(this);
            var h = now.data('height');
            var n = now.data('name');
            now.closest('div').append('<input type="hidden" class="val" name="'+n+'">');
            now.summernote({
                height: h,
                onChange: function() {
                    now.closest('div').find('.val').val(now.code());
                }
            });
            now.closest('div').find('.val').val(now.code());
        });
	}

    function option_count(type){
        var count = $('#option_count').val();
        if(type == 'add'){
            count++;
        }
        if(type == 'reduce'){
            count--;
        }
        $('#option_count').val(count);
    }

    function set_select(){
        $('.demo-chosen-select').chosen();
        $('.demo-cs-multiselect').chosen({width:'100%'});
    }
	
    $(document).ready(function() {
        set_select();
		set_summer();
		createColorpickers();
		set_switches();
    });
	
    function set_switches(){
        $(".main_param").each(function(){       
            var changeCheckbox = $(this).get(0);
            var changeField = $(this).closest('div').find('.main_param_state').get(0);
            if($(this).data('ty') == 'main'){
                var oks = '  <?php echo translate('main_parameter'); ?>';
                var nos = '  <?php echo translate('main_parameter'); ?>';
                var nat = 'main_param';
            } else if($(this).data('ty') == 'short'){
                var oks = '  <?php echo translate('short_description'); ?>';
                var nos = '  <?php echo translate('short_description'); ?>';
                var nat = 'short_description';
            }

            if($(this).closest('div').find('.main_param_state').html() == ''){
                if(changeCheckbox.checked){
                    var word = '' 
                            +'<span class="label label-success">'
                            + oks
                            +'</span>';
                } else {
                    var word = '' 
                            +'<span class="label label-danger">'
                            + nos
                            +'</span>';
                }
                
                new Switchery(changeCheckbox, {color:'rgb(100, 189, 99)', secondaryColor: '#cc2424', jackSecondaryColor: '#c8ff77'})
                changeField.innerHTML = word;
                changeCheckbox.onchange = function() {
                    if(changeCheckbox.checked){
                        var word = '' 
                                +'<span class="label label-success">'
                                + oks
                                +'</span>';
                        if($(this).closest('div').find('.temo_inp').length){
                            $(this).closest('div').find('.temo_inp').remove();
                        }
                    } else {
                        var word = '' 
                                +'<span class="label label-danger">'
                                + nos
                                +'</span>';
                        var tmp = '<input value="0" name="'+nat+'[]" class="temo_inp"  type="hidden" />';
                        $(this).closest('div').append(tmp);
                    }
                    changeField.innerHTML = word;
                };
            }           
        }); 
    }

    
    $('.delete-div-wrap .close').on('click', function() { 
	 	var pid = $(this).closest('.delete-div-wrap').find('img').data('id'); 
		var here = $(this); 
		msg = 'Really want to delete this Image?'; 
		bootbox.confirm(msg, function(result) {
			if (result) { 
				 $.ajax({ 
					url: base_url+'index.php/'+user_type+'/'+module+'/dlt_img/'+pid, 
					cache: false, 
					success: function(data) { 
						$.activeitNoty({ 
							type: 'success', 
							icon : 'fa fa-check', 
							message : 'Deleted Successfully', 
							container : 'floating', 
							timer : 3000 
						}); 
						here.closest('.delete-div-wrap').remove(); 
					} 
				}); 
			}else{ 
				$.activeitNoty({ 
					type: 'danger', 
					icon : 'fa fa-minus', 
					message : 'Cancelled', 
					container : 'floating', 
					timer : 3000 
				}); 
			}; 
		  }); 
		});

	
    function other(){
        set_select();
        $('#brn').show('slow');
        $('#fixed_additional_fields').show('slow');
		set_switches();
    }
    function get_cat(id){
        $('#brand').html('');
        $('#brn').hide('slow');
        $('#fixed_additional_fields').hide('slow');
        ajax_load(base_url+'index.php/admin/product/sub_by_cat/'+id,'sub_cat','other');
        ajax_load(base_url+'index.php/admin/product/fields_by_cat/'+id,'fixed_additional_fields','other');
    }
    function get_sub_res(id){}

    $(".unit").on('keyup',function(){
        $(".unit_set").html($(".unit").val());
    });

	function createColorpickers() {
	
		$('.demo2').colorpicker({
			format: 'rgba'
		});
		
	}
    
    $("#more_btn").click(function(){
        $("#more_additional_fields").append(''
            +'<div class="form-group">'
            +'    <div class="col-sm-2">'
            +'        <input type="text" name="ad_field_names[]" class="form-control"  placeholder="<?php echo translate('field_name'); ?>">'
            +'    </div>'
            +'    <div class="col-sm-4">'
            +'        <textarea rows="9"  class="summernotes" data-height="100" data-name="ad_field_values[]"></textarea>'
            +'    </div>'
            +'    <div class="col-sm-2">'
            +'        <input class="main_param" data-ty="main" value="ok" name="main_param_additional[]"  type="checkbox" />'
            +'        <span class="main_param_state"></span>'
            +'        <input value="0" name="main_param_additional[]" class="temo_inp"  type="hidden" />'
            +'    </div>'
            +'    <div class="col-sm-2">'
            +'        <input class="main_param" data-ty="short" value="ok" name="short_additional[]"  type="checkbox" />'
            +'        <span class="main_param_state"></span>'
            +'        <input value="0" name="short_additional[]" class="temo_inp"  type="hidden" />'
            +'    </div>'
            +'    <div class="col-sm-1">'
            +'        <span class="remove_it_v rmc btn btn-danger btn-icon icon-lg fa fa-trash" ></span>'
            +'    </div>'
            +'</div>'
        );
        set_summer();
        set_switches();
    });
    
    function next_tab(){
        $('.nav-tabs li.active').next().find('a').click();                    
    }
    function previous_tab(){
        $('.nav-tabs li.active').prev().find('a').click();                     
    }
    
    $("#more_option_btn").click(function(){
        option_count('add');
        var co = $('#option_count').val();
        $("#more_additional_options").append(''
            +'<div class="form-group" data-no="'+co+'">'
            +'    <div class="col-sm-4">'
            +'        <input type="text" name="op_title[]" class="form-control required"  placeholder="<?php echo translate('customer_input_title'); ?>">'
            +'    </div>'
            +'    <div class="col-sm-5">'
            +'        <select class="demo-chosen-select op_type required" name="op_type[]" >'
            +'            <option value="">(none)</option>'
            +'            <option value="text">Text Input</option>'
            +'            <option value="single_select">Dropdown Single Select</option>'
            +'            <option value="multi_select">Dropdown Multi Select</option>'
            +'            <option value="radio">Radio</option>'
            +'        </select>'
            +'        <div class="col-sm-12 options">'
            +'          <input type="hidden" name="op_set'+co+'[]" value="none" >'
            +'        </div>'
            +'    </div>'
            +'    <input type="hidden" name="op_no[]" value="'+co+'" >'
            +'    <div class="col-sm-2">'
            +'        <span class="remove_it_o rmo btn btn-danger btn-icon btn-circle icon-lg fa fa-times" onclick="delete_row(this)"></span>'
            +'    </div>'
            +'</div>'
        );
        set_select();
    });
    
    $("#more_additional_options").on('change','.op_type',function(){
        var co = $(this).closest('.form-group').data('no');
        if($(this).val() !== 'text' && $(this).val() !== ''){
            $(this).closest('div').find(".options").html(''
                +'    <div class="col-sm-12">'
                +'        <div class="col-sm-12 options margin-bottom-10"></div><br>'
                +'        <div class="btn btn-mint btn-labeled fa fa-plus pull-right add_op">'
                +'        <?php echo translate('add_options_for_choice');?></div>'
                +'    </div>'
            );
        } else if ($(this).val() == 'text' || $(this).val() == ''){
            $(this).closest('div').find(".options").html(''
                +'    <input type="hidden" name="op_set'+co+'[]" value="none" >'
            );
        }
    });
    
    $("#more_additional_options").on('click','.add_op',function(){
        var co = $(this).closest('.form-group').data('no');
        $(this).closest('.col-sm-12').find(".options").append(''
            +'    <div>'
            +'        <div class="col-sm-10">'
            +'          <input type="text" name="op_set'+co+'[]" class="form-control required"  placeholder="<?php echo translate('option_name'); ?>">'
            +'        </div>'
            +'        <div class="col-sm-2">'
            +'          <span class="remove_it_n rmon btn btn-danger btn-icon btn-circle icon-sm fa fa-times" onclick="delete_row(this)"></span>'
            +'        </div>'
            +'    </div>'
        );
    });
    
    $('body').on('click', '.rmo', function(){
        $(this).parent().parent().remove();
    });

    $('body').on('click', '.rmon', function(){
        var co = $(this).closest('.form-group').data('no');
        $(this).parent().parent().remove();
        if($(this).parent().parent().parent().html() == ''){
            $(this).parent().parent().parent().html(''
                +'   <input type="hidden" name="op_set'+co+'[]" value="none" >'
            );
        }
    });

    $('body').on('click', '.rms', function(){
        $(this).parent().parent().remove();
    });

    $("#more_color_btn").click(function(){
        $("#more_colors").append(''
            +'      <div class="col-md-12" style="margin-bottom:8px;">'
            +'          <div class="col-md-10">'
            +'              <div class="input-group demo2">'
			+'		     	   <input type="text" value="#ccc" name="color[]" class="form-control" />'
			+'		     	   <span class="input-group-addon"><i></i></span>'
			+'		        </div>'
            +'          </div>'
            +'          <span class="col-md-2">'
            +'              <span class="remove_it_v rmc btn btn-danger btn-icon icon-lg fa fa-trash" ></span>'
            +'          </span>'
            +'      </div>'
  		);
		createColorpickers();
    });		           

    $('body').on('click', '.rmc', function(){
        $(this).parent().parent().remove();
    });


	$(document).ready(function() {
		$("form").submit(function(e){
			return false;
		});
	});
</script>

<style>
	.btm_border{
		border-bottom: 1px solid #ebebeb;
		padding-bottom: 15px;	
	}
</style>


<!--Bootstrap Tags Input [ OPTIONAL ]-->



<?php
    }
?>
