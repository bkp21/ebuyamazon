<?php
	foreach($category_data as $row){
?>
	<div class="tab-pane fade active in" id="edit">
		<?php
			echo form_open(base_url() . 'index.php/admin/category/update/' . $row['category_id'], array(
				'class' => 'form-horizontal',
				'method' => 'post',
				'id' => 'category_edit',
				'enctype' => 'multipart/form-data'
			));
		?>
			<div class="panel-body">
	            <div class="form-group" style="margin-top:40px;">
	                <label class="col-sm-2 control-label" for="demo-hor-1">
                    	<?php echo translate('category_name');?>
                        	</label>
					<div class="col-sm-6">
						<input type="text" name="category_name"  
                        	value="<?php echo $row['category_name'];?>" id="demo-hor-1" 
                            	class="form-control required" placeholder="<?php echo translate('category_name');?>" >
					</div>
				</div>                         
                                            
	            <div class="form-group btm_border">
	                <label class="col-sm-2 control-label" for="demo-hor-11"><?php echo translate('fields');?></label>
	                <div class="col-sm-8 fields">
	                	<?php
	                		$fields = json_decode($row['fields'],true);
	                		foreach ($fields as  $val) {
	                	?>
				            <div class="form-group">
				                <div class="col-sm-5">
				                    <input type="text" name="field_name[]" class="form-control" value="<?php echo $val['name']; ?>"  placeholder="<?php echo translate('field_name'); ?>">
				                    <input type="hidden" name="num[]" value="<?php echo $val['no']; ?>" class="form-control" >
				                </div>
				                <div class="col-sm-3">
				                    <input class="main_param" data-ty="main" value="ok" name="main_param[]" <?php if($val['main'] == 'ok'){ echo 'checked'; } ?>  type="checkbox" />
				                    <span class="main_param_state"></span>
				                    <?php if($val['main'] == '0'){ ?>
				                    <input value="0" name="main_param[]" class="temo_inp"  type="hidden" />
				                    <?php } ?>
				                </div>
				                <div class="col-sm-3">
				                    <input class="main_param" data-ty="short" value="ok" name="short_description[]" <?php if($val['short'] == 'ok'){ echo 'checked'; } ?>  type="checkbox" />
				                    <span class="main_param_state"></span>
				                    <?php if($val['short'] == '0'){ ?>
				                    <input value="0" name="short_description[]" class="temo_inp"  type="hidden" />
				                    <?php } ?>
				                </div>
				                <div class="col-sm-1">
				                    <span class="remove_it_v rmc btn btn-danger btn-icon icon-sm fa fa-trash" ></span>
				                </div>
				            </div>	                		
	                	<?php
	                		}
	                	?>	                	
	                </div>
	            </div>
	            <div class="col-sm-offset-2 col-sm-4 btn btn-primary btn-labeled fa fa-plus-circle ad_field">
	                <?php echo translate('add_a_field'); ?>
	            </div>
			</div>
        
            <div class="panel-footer">
                <div class="row">
                    <div class="col-md-11">
                        <span class="btn btn-purple btn-labeled fa fa-refresh pro_list_btn pull-right" 
                        	onclick="ajax_set_full('edit','<?php echo translate('edit_category'); ?>','<?php echo translate('successfully_edited!'); ?>','category_edit','<?php echo $row['category_id']; ?>')">
                            	<?php echo translate('reset');?>
                        </span>
                    </div>
                    
                    <div class="col-md-1">
                        <span class="btn btn-success btn-md btn-labeled fa fa-upload pull-right" onclick="form_submit('category_edit','<?php echo translate('successfully_edited!'); ?>')" ><?php echo translate('upload');?></span>
                    </div>
                    
                </div>
            </div>
		</form>
	</div>
<?php
	}
?>

<script>
    $(".ad_field").click(function(){
        $(".fields").append(''
            +'<div class="form-group">'
            +'    <div class="col-sm-5">'
            +'        <input type="text" name="field_name[]" class="form-control"  placeholder="<?php echo translate('field_name'); ?>">'
            +'        <input type="hidden" name="num[]" value="no" class="form-control" >'
            +'    </div>'
            +'    <div class="col-sm-3">'
            +'        <input class="main_param" data-ty="main" value="ok" name="main_param[]"  type="checkbox" />'
            +'        <span class="main_param_state"></span>'
            +'        <input value="0" name="main_param[]" class="temo_inp"  type="hidden" />'
            +'    </div>'
            +'    <div class="col-sm-3">'
            +'        <input class="main_param" data-ty="short" value="ok" name="short_description[]"  type="checkbox" />'
            +'        <span class="main_param_state"></span>'
            +'        <input value="0" name="short_description[]" class="temo_inp"  type="hidden" />'
            +'    </div>'
            +'    <div class="col-sm-1">'
            +'        <span class="remove_it_v rmc btn btn-danger btn-icon icon-sm fa fa-trash" ></span>'
            +'    </div>'
            +'</div>'
        );
        set_switches();
    });
    
    $('body').on('click', '.rmc', function(){
        $(this).parent().parent().remove();
    });

    function set_switches(){
        $(".main_param").each(function(){       
            var changeCheckbox = $(this).get(0);
            var changeField = $(this).closest('div').find('.main_param_state').get(0);
            if($(this).data('ty') == 'main'){
                var oks = '  <?php echo translate('main_parameter'); ?>';
                var nos = '  <?php echo translate('main_parameter'); ?>';
                var nat = 'main_param';
            } else if($(this).data('ty') == 'short'){
                var oks = '  <?php echo translate('short_description'); ?>';
                var nos = '  <?php echo translate('short_description'); ?>';
                var nat = 'short_description';
            }

            if($(this).closest('div').find('.main_param_state').html() == ''){
                if(changeCheckbox.checked){
                    var word = '' 
                            +'<span class="label label-success">'
                            + oks
                            +'</span>';
                } else {
                    var word = '' 
                            +'<span class="label label-danger">'
                            + nos
                            +'</span>';
                }
                
                new Switchery(changeCheckbox, {color:'rgb(100, 189, 99)', secondaryColor: '#cc2424', jackSecondaryColor: '#c8ff77'})
                changeField.innerHTML = word;
                changeCheckbox.onchange = function() {
                    if(changeCheckbox.checked){
                        var word = '' 
                                +'<span class="label label-success">'
                                + oks
                                +'</span>';
                        if($(this).closest('div').find('.temo_inp').length){
                            $(this).closest('div').find('.temo_inp').remove();
                        }
                    } else {
                        var word = '' 
                                +'<span class="label label-danger">'
                                + nos
                                +'</span>';
                        var tmp = '<input value="0" name="'+nat+'[]" class="temo_inp"  type="hidden" />';
                        $(this).closest('div').append(tmp);
                    }
                    changeField.innerHTML = word;
                };
            }           
        }); 
    }
    
	$(document).ready(function() {
		set_switches();
		$("form").submit(function(e){
			return false;
		});
	});

</script>