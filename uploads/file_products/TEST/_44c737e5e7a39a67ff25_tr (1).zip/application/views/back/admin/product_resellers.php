<div>
    <?php
		echo form_open(base_url() . 'index.php/admin/product/set_resellers/'.$product, array(
			'class' => 'form-horizontal',
			'method' => 'post',
			'id' => 'product_resellers',
			'enctype' => 'multipart/form-data'
		));
        $res = $this->db->get_where('product',array('product_id'=>$product))->row()->resellers;
	?>
        <div class="panel-body">

            <div class="form-group">
                <label class="col-sm-4 control-label" for="demo-hor-1"><?php echo translate('current_quantity');?></label>
                <div class="col-sm-6">
                    <?php echo $this->crud_model->select_html('reseller','reseller','reseller_name','edit','demo-cs-multiselect',$res); ?>
                </div>
            </div>
            
        </div>
    </form>
</div>

<script type="text/javascript">

    $(document).ready(function() {
        $('.demo-chosen-select').chosen();
        $('.demo-cs-multiselect').chosen({width:'100%'});
    });


	$(document).ready(function() {
		$("form").submit(function(e){
			return false;
		});
	});
</script>

